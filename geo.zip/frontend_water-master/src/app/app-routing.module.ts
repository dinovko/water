import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForbiddenComponent } from './shared/components/forbidden/forbidden.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./features/main/main.module').then(m => m.MainModule),
    data: { title: 'Map Water KZ' },
  },
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.module').then(m => m.AdminModule),
    data: { title: 'Адиминистрирование' },
  },
  {
    path: 'data',
    loadChildren: () => import('./features/datas/datas.module').then(m => m.DatasModule),
    data: { title: 'Ввода данных' },
  },
  { path: '**', redirectTo: 'not-found', data: { title: 'Не найдено' } },
  { path: 'not-found', component: ForbiddenComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
