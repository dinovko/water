import { Component, ChangeDetectorRef } from '@angular/core';
import { MainService } from './features/main/main.service';
import { MediaMatcher } from '@angular/cdk/layout';
import { AuthService } from './auth/services/auth.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  opened = this.mainService.opened;
  mobileQuery = this.mainService.mobileQuery;

  constructor(
    public mainService: MainService,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private auth: AuthService,
    private matDialog: MatDialog,
  ) {
    mainService.mobileQuery = media.matchMedia('(max-width: 777px)');
    mainService.mobileQueryListener = () => {
      changeDetectorRef.detectChanges();
      // setTimeout(() => {
      this.matDialog.closeAll();
      // });
    };
    mainService.mobileQuery.addListener(mainService.mobileQueryListener);
    if (localStorage.getItem('access_token')) {
      auth.checkUserAuthorities();
    }
  }
  title = 'water';
  snavToggle() {
    this.mainService.opened.next(!this.mainService.opened.value);
  }
}
