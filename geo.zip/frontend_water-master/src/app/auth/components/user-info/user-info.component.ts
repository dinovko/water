import { Component, OnDestroy } from '@angular/core';
import { CurrentUser } from '../../services/current.service';
import { MatDialog } from '@angular/material/dialog';
import { LoginComponent } from '../login/login.component';
import { Router } from '@angular/router';
import { Subscription, Observable } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { MainService } from 'src/app/features/main/main.service';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.scss'],
})
export class UserInfoComponent implements OnDestroy {
  public userInfo;
  public user$: Observable<any>;
  public userInfo$: Subscription;
  constructor(
    private matDialog: MatDialog,
    private router: Router,
    private currentUser: CurrentUser,
    private auth: AuthService,
    public mainService: MainService,
  ) {
    this.user$ = currentUser.user$;
    this.userInfo$ = currentUser.user$.subscribe(user => {
      if (user) {
        this.userInfo = user;
      }
    });
  }
  public get signed(): boolean {
    return (localStorage.getItem('access_token') && localStorage.getItem('refresh_token')) !== null;
  }

  ngOnDestroy(): void {
    this.userInfo$.unsubscribe();
  }
  openLoginDialog() {
    this.matDialog.open(LoginComponent, {
      maxHeight: '90vh',
      minHeight: '35vh',
      minWidth: '30vw',
      maxWidth: '90vw',
      panelClass: 'dialog_withoutPadding_with_radius',
    });
  }

  onLogout() {
    localStorage.clear();
    this.router.navigate(['/']);
    this.currentUser.setUser(null);
    this.auth.authorized.next(false);
  }
}
