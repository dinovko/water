import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { publishReplay, shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CurrentUser {
  private _user = new BehaviorSubject<any>(null);

  constructor() {}

  public setUser(user: any): void {
    this._user.next(user);
  }

  public get user$(): Observable<any> {
    return this._user.asObservable().pipe(shareReplay(1));
  }

  public get user(): any {
    return this._user.getValue();
  }
}
