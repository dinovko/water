import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'role',
})
export class RolePipe implements PipeTransform {
  transform(user: any, roleName: string): boolean {
    if (!user) {
      return false;
    } else {
      return user.roles.some(element => element.code === roleName);
    }
  }
}
