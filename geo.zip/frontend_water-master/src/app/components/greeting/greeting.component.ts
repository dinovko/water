import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { constants } from 'src/app/сonstants';
import { RegionsService } from 'src/app/shared/services/regions.service';

@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GreetingComponent implements OnInit {
  @Input() closed = true;
  constructor(public regionsService: RegionsService) {}
  currentMonth: string = new Date().toLocaleString('ru-ru', { month: 'long', year: 'numeric' });

  ngOnInit(): void {
    // отображаем приветственное окно не чаще 1 раза в определенный промежуток времени (constants.noGreetingTime)
    if (!this.getCookie('greetingIsShowed')) {
      this.closed = false;
      this.regionsService.getFullInfoKz();
    }
  }

  onClose() {
    this.closed = true;
    document.cookie = 'greetingIsShowed=yes; max-age=' + constants.noGreetingTime;
  }

  getCookie = name => {
    const matches = document.cookie.match(
      new RegExp('(?:^|; )' + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + '=([^;]*)'),
    );
    return matches ? decodeURIComponent(matches[1]) : undefined;
  };
}

@Component({
  selector: 'app-m-greeting',
  templateUrl: './mobile/m-greeting.component.html',
  styleUrls: ['./mobile/m-greeting.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MobileGreetingComponent extends GreetingComponent {}
