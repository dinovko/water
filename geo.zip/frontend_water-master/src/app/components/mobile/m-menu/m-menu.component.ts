import { Component, OnDestroy } from '@angular/core';
import { constants } from 'src/app/сonstants';
import { Router, RouterEvent, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { CurrentUser } from 'src/app/auth/services/current.service';

interface Tab {
  label: string;
  route: string;
  iconClass: string;
  role: any;
}

@Component({
  selector: 'app-m-menu',
  templateUrl: './m-menu.component.html',
})
export class MMenuComponent implements OnDestroy {
  tabs: Tab[] = constants.mainTabs;
  currentRouteUrl: string;
  activatedUrl: string = '';
  subscription: Subscription = new Subscription();

  constructor(private router: Router, private _user: CurrentUser) {
    const roleSubscr = _user.user$.subscribe(data => {
      if (data) {
        this.tabs[1].role = true;
      } else {
        this.tabs[1].role = false;
      }
    });
    this.subscription.add(roleSubscr);

    const routeSubscr = router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((r: NavigationEnd) => {
        this.activatedUrl = r.urlAfterRedirects;

        const firstPartOfRoute = this.activatedUrl.split('/').filter(urlPart => urlPart)[0] ?? '';
        const withoutQueryparams = firstPartOfRoute.split('?')[0];
        this.currentRouteUrl = withoutQueryparams;
      });
    this.subscription.add(routeSubscr);
  }

  routeNavigate(tab: Tab) {
    const urlPreffix =
      this.activatedUrl.indexOf('/', 1) > -1
        ? this.activatedUrl.substring(this.activatedUrl.indexOf('/', 1))
        : '';
    this.router.navigate([tab.route + urlPreffix]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
