import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/api.config';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private http: HttpClient) {}

  getAllRoles(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/users/allRoles`);
  }

  getAllUsers(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/users/allUsers`);
  }

  getAllStatuses(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/users/allStatuses`);
  }

  getAllOrganizations(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/users/allOrganizations`);
  }

  getAllSystems(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/allSystems`);
  }

  editUser(body): Observable<any> {
    return this.http.put(`${ApiConfig.waterApi}/users`, body);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${ApiConfig.waterApi}/users/${id}`);
  }

  addUser(body): Observable<any> {
    return this.http.post(`${ApiConfig.waterApi}/users`, body);
  }
}
