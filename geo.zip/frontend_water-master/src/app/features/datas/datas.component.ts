import { Component, OnInit, OnDestroy } from '@angular/core';
import { DatasService } from './datas.service';
import {
  Settlement,
  SettlementWater,
  FinanceSettlementWaters,
  newRequestFinance,
} from './datas.model';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';
import { CurrentUser } from 'src/app/auth/services/current.service';
import { Subscription } from 'rxjs';
import { Map, View } from 'ol';
import { MapService } from 'src/app/features/main/map/map.service';
import { constants } from 'src/app/сonstants';
import { NotificationDialogComponent } from 'src/app/shared/components/notification-dialog/notification-dialog.component';
import { MatDatepicker } from '@angular/material/datepicker';

@Component({
  selector: 'app-datas',
  templateUrl: './datas.component.html',
  styleUrls: ['./datas.component.scss'],
})
export class DatasComponent implements OnInit, OnDestroy {
  dataRegions = [];
  dataDistricts = [];
  dataSettlements = [];
  dataWaterSources = [];

  selected = 'м³';
  btnSave = false;
  btnRemove = false;
  deleteFinanceId;
  loading = false;
  selectedRaionId = null;
  settlement: Settlement = new Settlement();
  settlementWater: SettlementWater = new SettlementWater();
  map: Map = null;
  isOpenAddModal = true;
  selectedSettlement = null;
  selectedDistrict = null;
  filterByParam;
  financeSettlementWaters: FinanceSettlementWaters = new FinanceSettlementWaters();
  newRequestFinance: newRequestFinance = new newRequestFinance();
  datafinanceType = [];
  public userInfo;
  dataSource = new MatTableDataSource();
  displayedColumns: string[] = [
    'projectName',
    'implementationFrom',
    'financeLb',
    'financeRbKvr',
    'financeRbKds',
    'dicFinanceType',
    'finishDate',
    'btn',
  ];
  public user$: Subscription;
  constructor(
    private datasService: DatasService,
    private matDialog: MatDialog,
    private datePipe: DatePipe,
    private _user: CurrentUser,
    public mapService: MapService,
  ) {
    this.user$ = _user.user$.subscribe(user => {
      this.userInfo = user;
    });
  }
  ngOnInit() {
    this.getRegions();
    this.allWaterSources();
    this.allFinanceTypes();
    this.settlementWater.dicWaterSource = {};
    this.newRequestFinance.dicFinanceType = {};
  }
  ngOnDestroy(): void {
    this.user$.unsubscribe();
  }
  getRegions() {
    this.clearAll();
    this.datasService
      .getRegion()
      .toPromise()
      .then(dataRegions => {
        dataRegions.forEach(element => {
          this.userInfo.organizations.forEach(element2 => {
            if (element.code === element2.code) this.dataRegions.push(element);
          });
        });
        this.btnSave = false;
      });
  }
  getDistricts(id) {
    this.clearAll();
    this.selectedDistrict = null;
    this.selectedSettlement = null;
    this.dataSettlements = [];
    this.datasService
      .getDistricts(id)
      .toPromise()
      .then(dataDistricts => {
        this.dataDistricts = dataDistricts;
        this.btnSave = false;
      });
  }
  getSettlements(id, newGid = null) {
    this.clearAll();
    this.selectedSettlement = null;
    this.datasService
      .getSettlements(id)
      .toPromise()
      .then(dataSettlements => {
        this.dataSettlements = dataSettlements;
        dataSettlements.forEach(element => {
          if (!element.nameRu) element.nameRu = '';
        });
        this.filterByParam = this.dataSettlements.slice();
        if (newGid) this.selectedSettlement = newGid;
      });
  }
  getSettlementsData(id) {
    this.datasService
      .getSettlementsData(id)
      .toPromise()
      .then(settlementsData => {
        settlementsData.settlementWater.needRbKvr = settlementsData.settlementWater.needRbKvr
          ? settlementsData.settlementWater.needRbKvr / 1000
          : settlementsData.settlementWater.needRbKvr;
        settlementsData.settlementWater.needRbKds = settlementsData.settlementWater.needRbKds
          ? settlementsData.settlementWater.needRbKds / 1000
          : settlementsData.settlementWater.needRbKds;
        settlementsData.settlementWater.needLb = settlementsData.settlementWater.needLb
          ? settlementsData.settlementWater.needLb / 1000
          : settlementsData.settlementWater.needLb;

        settlementsData.settlementWater.financeSettlementWaters.forEach(finance => {
          finance.financeRbKvr = finance.financeRbKvr
            ? finance.financeRbKvr / 1000
            : finance.financeRbKvr;
          finance.financeRbKds = finance.financeRbKds
            ? finance.financeRbKds / 1000
            : finance.financeRbKds;
          finance.financeLb = finance.financeLb ? finance.financeLb / 1000 : finance.financeLb;
        });
        this.btnSave = true;
        this.dataSource = new MatTableDataSource([]);
        this.settlement = settlementsData;
        if (this.settlement.settlementWater) {
          this.btnRemove = true;
          if (this.settlement.settlementWater.dicWaterSource == null) {
            this.settlement.settlementWater.dicWaterSource = {};
          }
          this.settlementWater = { ...this.settlement.settlementWater };
        } else {
          this.settlementWater = Object();
          this.settlementWater.dicWaterSource = {};
        }
        if (!this.settlement.settlementWater) {
          this.financeSettlementWaters.dicFinanceType = {};
        } else {
          this.dataSource = new MatTableDataSource(
            this.settlement.settlementWater.financeSettlementWaters,
          );
        }
      });
  }
  selectet(item) {
    this.settlementWater.dicWaterSource = { ...item };
  }
  selectet2(item) {
    this.newRequestFinance.dicFinanceType = { ...item };
  }
  allWaterSources() {
    this.datasService
      .allWaterSources()
      .toPromise()
      .then(dataWaterSources => {
        this.dataWaterSources = dataWaterSources;
      });
  }
  allFinanceTypes() {
    this.datasService
      .allFinanceTypes()
      .toPromise()
      .then((datafinanceType: any) => {
        this.datafinanceType = datafinanceType;
      })
      .catch(err => {
        let result = 'Ошибка';
        let status = 'Проверьте пожалуйста все введенные данные';
        this.result('modal', result, 'error', status);
      });
  }
  onClickAddSettlement(modal: any) {
    this.isOpenAddModal = true;
    let dialog = this.matDialog.open(modal);
    dialog.afterOpened().subscribe(result => {
      this.initMap();
    });
  }
  onClickEditSettlement(modal: any) {
    this.isOpenAddModal = false;
    let dialog = this.matDialog.open(modal);
    dialog.afterOpened().subscribe(result => {
      this.initMap();
    });
  }
  openDialogDeleteSettlement(modal: any) {
    this.matDialog.open(modal, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
    });
  }

  onClickDeleteSettlement() {
    this.datasService
      .deleteSettlement(this.selectedSettlement)
      .toPromise()
      .then(() => {
        let result = 'Успешно удален';
        let status = 'Запрос на удаление';
        this.result('modal', result, 'success', status);
        this.getSettlements(this.selectedDistrict);
        this.clearAll();
      })
      .catch(err => {
        let result = 'Ошибка';
        let status = 'Запрос на удаление';
        this.result('modal', result, 'error', status);
      });
  }
  onClickSaveEditMap() {
    let centerCoordinate = this.map.getView().getCenter();
    let wkt =
      'POINT(' + centerCoordinate[0].toString() + ' ' + centerCoordinate[1].toString() + ')';
    if (this.isOpenAddModal) {
      this.datasService
        .addSettlement(this.selectedDistrict, wkt)
        .toPromise()
        .then(newGid => {
          let result = 'Добавлено';
          let status = 'Запрос на добавление';
          this.result('modal', result, 'success', status);
          this.btnSave = true;
          this.getSettlements(this.selectedDistrict, newGid);
          this.getSettlementsData(newGid);
        })
        .catch(err => {
          let result = 'Ошибка';
          let status = 'Проверьте пожалуйста все введенные данные';
          this.result('modal', result, 'error', status);
        });
    } else {
      this.datasService
        .updateSettlement(this.selectedSettlement, wkt)
        .toPromise()
        .then(() => {
          let result = 'Успешно изменен';
          let status = 'Запрос на изменение';
          this.result('modal', result, 'success', status);
          this.getSettlementsData(this.selectedSettlement);
        })
        .catch(err => {
          let result = 'Ошибка';
          let status = 'Запрос на изменение';
          this.result('modal', result, 'error', status);
        });
    }
  }
  onOpenDialog(modal: any, query) {
    if (query != 'add') {
      if (query.dicFinanceType == null) {
        query.dicFinanceType = {};
      }
      query.edit = 'edit';
      this.newRequestFinance = { ...query };
    }
    this.matDialog.open(modal, {
      maxHeight: '100vh',
      minHeight: '40vh',
      minWidth: '30vw',
      maxWidth: '54vw',
    });
  }
  initMap() {
    this.map = new Map({
      target: 'editMap',
      layers: [this.mapService.getBaseLayer2()],
      view: new View({
        extent: constants.map.extent,
        center: constants.map.center,
        zoom: constants.map.zoom,
      }),
    });
  }
  index = 0;
  addTableList() {
    this.newRequestFinance.implementationFrom = this.datePipe.transform(
      this.newRequestFinance.implementationFrom,
      'yyyy-MM-dd',
    );
    this.newRequestFinance.implementationTo = this.datePipe.transform(
      this.newRequestFinance.implementationTo,
      'yyyy-MM-dd',
    );
    this.newRequestFinance.finishDate = this.datePipe.transform(
      this.newRequestFinance.finishDate,
      'yyyy-MM-dd',
    );
    if (this.newRequestFinance.edit) {
      for (let i = 0; i < this.settlement.settlementWater.financeSettlementWaters.length; i++) {
        if (this.settlement.settlementWater.financeSettlementWaters[i].id) {
          if (
            this.settlement.settlementWater.financeSettlementWaters[i].id ===
            this.newRequestFinance.id
          ) {
            this.settlement.settlementWater.financeSettlementWaters[i] = this.newRequestFinance;
          }
        }
        if (this.settlement.settlementWater.financeSettlementWaters[i].index) {
          if (
            this.settlement.settlementWater.financeSettlementWaters[i].index ===
            this.newRequestFinance.index
          ) {
            this.settlement.settlementWater.financeSettlementWaters[i] = this.newRequestFinance;
          }
        }
      }
    } else {
      this.index += 1;
      this.newRequestFinance.index = this.index;
      this.settlement.settlementWater.financeSettlementWaters.push(this.newRequestFinance);
    }
    this.dataSource = new MatTableDataSource(
      this.settlement.settlementWater.financeSettlementWaters,
    );
    delete this.newRequestFinance.edit;
    this.newRequestFinance = Object();
    this.newRequestFinance.dicFinanceType = {};
  }

  openDialogDeleteFinance(modal: any, element) {
    this.deleteFinanceId = element.id;
    this.matDialog.open(modal, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
    });
  }

  deleteFinance() {
    if (this.deleteFinanceId) {
      this.datasService
        .deleteFinance(this.deleteFinanceId)
        .toPromise()
        .then((dataStatus: any) => {
          let result = 'Успешно удален';
          let status = 'Запрос на удаление';
          this.result('modal', result, 'success', status);
          this.settlement.settlementWater.financeSettlementWaters = this.settlement.settlementWater.financeSettlementWaters.filter(
            f => f.id !== this.deleteFinanceId,
          );
          this.getSettlementsData(this.settlement.gid);
          this.dataSource = new MatTableDataSource(
            this.settlement.settlementWater.financeSettlementWaters,
          );
        })
        .catch(err => {
          let result = 'Ошибка';
          let status = 'Запрос на удаление';
          this.result('modal', result, 'error', status);
        });
    } else {
      let result = 'Успешно удален';
      let status = 'Запрос на удаление';
      this.result('modal', result, 'success', status);
      this.settlement.settlementWater.financeSettlementWaters = this.settlement.settlementWater.financeSettlementWaters.filter(
        f => f.id !== this.deleteFinanceId,
      );
      this.getSettlementsData(this.settlement.gid);
      this.dataSource = new MatTableDataSource(
        this.settlement.settlementWater.financeSettlementWaters,
      );
    }
  }

  openDialogRemoveSettlement(modal: any) {
    this.matDialog.open(modal, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
    });
  }

  removeSettlement() {
    // if (confirm('Удалить обеспеченность?') === true) {
    this.loading = true;
    this.datasService
      .removeSettlement(this.settlement.settlementWater.id)
      .toPromise()
      .then((dataStatus: any) => {
        this.loading = false;
        let result = 'Успешно удален';
        let status = 'Запрос на удаление';
        this.result('modal', result, 'success', status);
        this.btnRemove = false;
        this.getSettlementsData(this.settlement.gid);
      })
      .catch(err => {
        let result = 'Ошибка';
        let status = 'Запрос на удаление';
        this.result('modal', result, 'error', status);
      });
    // } else {
    // }
  }
  createNewDatas() {
    this.loading = true;
    this.settlement.settlementWater.financeSettlementWaters.forEach(item => {
      if (item.index) {
        delete item.index;
      }
      if (item.edit) {
        delete item.edit;
      }
    });
    if (!this.settlement.gid) this.settlement.gid = this.selectedSettlement;
    if (this.settlementWater) {
      if (this.settlementWater.isSpecProject) {
        this.settlementWater.isSpecProject = 1;
      } else {
        this.settlementWater.isSpecProject = 0;
      }

      this.settlementWater.isGroupFinance = this.settlementWater.isGroupFinance ? 1 : 0;

      this.settlementWater.needImplementationFrom = this.datePipe.transform(
        this.settlementWater.needImplementationFrom,
        'yyyy-MM-dd',
      );
      this.settlementWater.needImplementationTo = this.datePipe.transform(
        this.settlementWater.needImplementationTo,
        'yyyy-MM-dd',
      );
      this.settlement.settlementWater = { ...this.settlementWater };
    }
    if (!this.settlement.settlementWater.financeSettlementWaters) {
      this.settlement.settlementWater.financeSettlementWaters = [];
    }
    const body: Settlement = JSON.parse(JSON.stringify(this.settlement));
    delete body['udate'];
    delete body['idate'];
    delete body['userIin'];
    delete body.settlementWater['udate'];
    delete body.settlementWater['idate'];
    delete body.settlementWater['userIin'];
    body.settlementWater.financeSettlementWaters = body.settlementWater.financeSettlementWaters.map(
      f => {
        delete f['udate'];
        delete f['idate'];
        delete f['userIin'];
        return f;
      },
    );

    body.settlementWater.financeSettlementWaters.forEach(finance => {
      finance.financeRbKvr = finance.financeRbKvr
        ? finance.financeRbKvr * 1000
        : finance.financeRbKvr;
      finance.financeRbKds = finance.financeRbKds
        ? finance.financeRbKds * 1000
        : finance.financeRbKds;
      finance.financeLb = finance.financeLb ? finance.financeLb * 1000 : finance.financeLb;
    });

    body.settlementWater.needRbKvr = body.settlementWater.needRbKvr
      ? body.settlementWater.needRbKvr * 1000
      : body.settlementWater.needRbKvr;
    body.settlementWater.needRbKds = body.settlementWater.needRbKds
      ? body.settlementWater.needRbKds * 1000
      : body.settlementWater.needRbKds;
    body.settlementWater.needLb = body.settlementWater.needLb
      ? body.settlementWater.needLb * 1000
      : body.settlementWater.needLb;

    this.datasService
      .createNewDatas(body)
      .toPromise()
      .then((data: any) => {
        this.loading = false;
        let result = 'Успешно';
        let status = 'Запрос на добавление';
        this.result('modal', result, 'success', status);
        let settlementGid: number = this.settlement.gid;
        this.getSettlements(this.selectedDistrict, this.selectedSettlement);
        this.getSettlementsData(settlementGid);
      })
      .catch(err => {
        this.loading = false;
        let result = 'Ошибка';
        let status = 'Проверьте пожалуйста все введенные данные';
        this.result('modal', result, 'error', status);
      });
  }
  clearAll() {
    this.settlement = new Settlement();
    this.settlementWater = new SettlementWater();
    this.settlementWater.dicWaterSource = {};
    this.financeSettlementWaters = new FinanceSettlementWaters();
    this.newRequestFinance = new newRequestFinance();
    this.newRequestFinance.dicFinanceType = {};
    this.dataSource = new MatTableDataSource([]);
  }

  result(modal: any, result, res, status) {
    this.matDialog.open(NotificationDialogComponent, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
      data: { result, res, status },
    });
  }

  yearChoosen(date: Date, datepicker: MatDatepicker<any>, field: string, startOfYear = true) {
    const selectedYear = date.getFullYear();
    // 01.01.{выбранный год} **либо** 31.12.{выбранный год}
    const _date = startOfYear ? new Date(selectedYear, 0) : new Date(selectedYear, 12, 0);
    this.settlementWater[field] = _date;
    datepicker.close();
  }

  clearDate(field: string, datepicker: MatDatepicker<any>, parent?) {
    this[parent ? parent : 'settlementWater'][field] = null;
    setTimeout(() => {
      datepicker.close();
    });
  }
}
