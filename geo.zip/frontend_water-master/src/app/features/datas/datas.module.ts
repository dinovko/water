import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { DatasComponent } from './datas.component';
import { DatasRoutingModule } from './datas-routing.module';

@NgModule({
  declarations: [DatasComponent],
  imports: [CommonModule, SharedModule, DatasRoutingModule],
})
export class DatasModule {}
