import { Injectable, ChangeDetectorRef } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MainService {
  mapLoading = new BehaviorSubject(false);
  mobileQuery: MediaQueryList;
  mobileQueryListener: () => void;
  opened = new BehaviorSubject<boolean>(true);
}
