import { Component, Input, AfterViewInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets, ChartTooltipItem, ChartData } from 'chart.js';
import { Label } from 'ng2-charts';
import { Region } from 'src/app/shared/models/mapInfo';
@Component({
  selector: 'app-diagram',
  templateUrl: './diagram.component.html',
  styleUrls: ['./diagram.component.scss'],
})
// сначала отсортировать потом взять суммы и т.д
export class DiagramComponent implements AfterViewInit {
  @Input() readonly inputData: Region[];
  @Input() displayName: string;
  /**
   * от этого зависит какие поля массива inputData будут отображаться
   */
  @Input() diagramType: 'finance' | 'needs';

  dataIsCorrect = false;
  data: Region[];

  constructor() {}
  public barChartOptions: ChartOptions = {
    title: {
      text: 'Области',
      fontColor: '#000',
      fontFamily: 'Roboto',
      fontSize: 20,
      display: false,
      position: 'top',
      padding: 30,
    },
    legend: { position: 'top', align: 'end', fullWidth: false },
    tooltips: {
      // пока не удалять: стили с фигмы, надо решить применить/нет
      titleFontColor: '#828282',
      backgroundColor: '#FAFAFA',
      bodyFontColor: ' #70CBFF',
      bodyFontSize: 14,
      bodyFontStyle: 'bold',
      bodyAlign: 'center',
      bodyFontFamily: 'Roboto',
      borderColor: 'rgba(0, 0, 0, 0.3)',
      borderWidth: 1,
      mode: 'single',
      displayColors: false,
      intersect: false,
      xPadding: 12,
      yPadding: 12,
      callbacks: {
        label(item: ChartTooltipItem, data: ChartData) {
          return `${item.xLabel.toLocaleString()} тг из ${item.datasetIndex ? 'МБ' : 'РБ'}`;
        },
        labelTextColor(item: ChartTooltipItem, data: Chart) {
          return item.datasetIndex ? 'rgba(0, 153, 239, 1)' : 'rgba(112, 203, 255, 1)';
        },
      },
    },
    responsive: true,
    maintainAspectRatio: false,
    aspectRatio: 2,
    scales: {
      xAxes: [
        {
          ticks: {
            fontColor: '#000',
            fontFamily: 'Roboto',
            fontSize: 14,
            callback(val: number, i: number, values: number[]) {
              return val.toLocaleString();
            },
          },
          gridLines: { color: '#E0E0E0' },
        },
      ],
      yAxes: [
        {
          ticks: {
            fontColor: '#000',
            fontFamily: 'Roboto',
            fontSize: 14,
            display: true,
            autoSkip: false,
          },
          gridLines: { display: false },
        },
      ],
    },
    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
      },
    },
  };
  barChartLabels: Label[];
  public barChartType: ChartType = 'horizontalBar';
  public barChartData: ChartDataSets[];

  /**
   * фыв
   */
  dataIsNotNull = (region: Region) => {
    switch (this.diagramType) {
      case 'finance':
        const rbFinSum = region.financeRbKds + region.financeRbKvr;
        return rbFinSum || region.financeLb > 0;
      case 'needs':
        const rbNeedSum = region.needRbKvr + region.needRbKds;
        return rbNeedSum || region.needTotalCost > 0;
      default:
        return false;
    }
  };

  rbData: (region: Region) => number = (region: Region) => {
    switch (this.diagramType) {
      case 'finance':
        return region.financeRbKvr + region.financeRbKds;
      case 'needs':
        return region.needRbKvr + region.needRbKds;
    }
  };

  lbData: (region: Region) => number = (region: Region) => {
    switch (this.diagramType) {
      case 'finance':
        return region.financeLb;
      case 'needs':
        return region.needLb;
    }
  };

  ngAfterViewInit() {
    setTimeout(() => {
      this.dataIsCorrect = this.inputData.some(this.dataIsNotNull);
      this.data = this.inputData.sort((a, b) =>
        a[this.displayName]?.localeCompare(b[this.displayName]),
      );
      this.barChartLabels = this.data.map(reg => reg[this.displayName]);
      this.barChartData = [
        {
          data: this.data.map(this.rbData) as number[],
          label: 'Республиканский бюджет',
          backgroundColor: 'rgba(112, 203, 255, .8)',
          hoverBackgroundColor: 'rgba(112, 203, 255, 1)',
          barThickness: 10,
        },
        {
          data: this.data.map(this.lbData) as number[],
          label: 'Местный бюджет',
          backgroundColor: 'rgba(0, 153, 239, .8)',
          hoverBackgroundColor: 'rgba(0, 153, 239, 1)',
          barThickness: 10,
        },
      ];
    });
  }

  // events
  public chartClicked({ event, active }: { event: MouseEvent; active: {}[] }): void {
    console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent; active: {}[] }): void {
    console.log(event, active);
  }
}
