import {
  Component,
  ViewChild,
  ElementRef,
  AfterViewInit,
  Input,
  SimpleChanges,
  OnChanges,
  OnDestroy,
  ChangeDetectionStrategy,
  EventEmitter,
  Output,
} from '@angular/core';
import { Overlay } from 'ol';
import OverlayPositioning from 'ol/OverlayPositioning';
import { Region } from 'src/app/shared/models/mapInfo';
import { MapService } from 'src/app/features/main/map/map.service';
import { constants } from 'src/app/сonstants';

@Component({
  selector: 'app-map-popup',
  templateUrl: './map-popup.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapPopupComponent implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('identPopup') identPopup: ElementRef;
  @Input() coordinates: [number, number];
  @Input() data: Region;
  @Output() opened = new EventEmitter<Region>();
  overlay: Overlay;
  constructor(private mapService: MapService) {}

  ngAfterViewInit(): void {
    this.initPopup();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.overlay?.setPosition(this.coordinates);
  }

  initPopup() {
    this.overlay = new Overlay({
      element: this.identPopup.nativeElement,
      autoPan: true,
      autoPanAnimation: {
        duration: constants.map.duration,
      },
      positioning: OverlayPositioning.CENTER_LEFT,
      offset: [18, 0],
    });

    this.overlay.set('name', 'identOverlay');
    this.mapService.map.addOverlay(this.overlay);
    this.overlay.setPosition(this.coordinates);
  }

  close() {
    this.overlay?.setPosition(undefined);
  }

  onOpenClick() {
    this.opened.emit(this.data);
  }

  ngOnDestroy(): void {
    this.overlay?.setPosition(undefined);
    this.mapService.map.removeOverlay(this.overlay);
  }
}

@Component({
  selector: 'app-map-popup-finance',
  templateUrl: './map-popup-finance.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapPopupFinanceComponent extends MapPopupComponent {}

@Component({
  selector: 'app-map-popup-needs',
  templateUrl: './map-popup-needs.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapPopupNeedsComponent extends MapPopupComponent {}
