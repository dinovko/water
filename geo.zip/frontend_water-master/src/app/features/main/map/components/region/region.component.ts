import { Component, AfterViewInit, OnDestroy } from '@angular/core';
import { MapService } from 'src/app/features/main/map/map.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MainService } from 'src/app/features/main/main.service';
import { Region } from 'src/app/shared/models/mapInfo';
import { RegionsService } from 'src/app/shared/services/regions.service';

@Component({
  selector: 'app-region',
  template: `
    <div class="map-info" *ngIf="regionData && !mainService.mobileQuery?.matches">
      <app-map-info [data]="regionData"></app-map-info>
    </div>
    <app-map-popup
      *ngIf="mapService.selectedFeature && !mainService.mobileQuery?.matches"
      [coordinates]="mapService.selectedFeature?.get('popupCoordinates')"
      [data]="mapService.selectedFeature?.get('data')"
      (opened)="onOpen($event)"
    ></app-map-popup>
    <app-table
      *ngIf="selectedRegionDistricts?.length && !mainService.mobileQuery?.matches"
      [inputData]="selectedRegionDistricts"
      [tableType]="'potrebnost'"
    ></app-table>
    <app-m-bread-crumbs
      *ngIf="selectedRegionDistricts?.length && mainService.mobileQuery?.matches && regionData"
      [data]="selectedRegionDistricts"
      [mapInfo]="regionData"
    ></app-m-bread-crumbs>
  `,
})
export class RegionComponent implements AfterViewInit, OnDestroy {
  regionGid = this.activatedRoute.snapshot.params.regionid;
  regionData: Region;
  selectedRegionDistricts: Region[]; // чтобы передать в app-diagram, в district компоненте так же можно сделать
  constructor(
    public mapService: MapService,
    public regionsService: RegionsService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public mainService: MainService,
  ) {}

  ngAfterViewInit(): void {
    if (!this.regionsService.regions || this.regionsService.regions.length === 0) {
      setTimeout(() => {
        this.regionsService.getRegions(this.getRegionDataAndZoom);
      });
    } else {
      setTimeout(() => {
        this.getRegionDataAndZoom(this.regionsService.regions);
      });
    }
  }

  getRegionDataAndZoom = (regions: Region[]) => {
    // tslint:disable-next-line: triple-equals
    this.regionData = regions.find(region => region.regionGid == this.regionGid);
    this.mapService.setFullKzView();
    this.mapService.zoomToGeom(this.regionData.wkt);

    this.selectedRegionDistricts = this.regionsService.districts.filter(
      // tslint:disable-next-line: triple-equals
      (district: Region) => district.regionGid == this.regionData.regionGid,
    );
    if (this.regionsService.districts.length === 0 || !this.selectedRegionDistricts?.length) {
      this.regionsService.getDistricts(this.regionData.regionGid, this.drawDistricts);
    } else {
      this.drawDistricts(this.selectedRegionDistricts);
    }
  };

  drawDistricts = (districts: Region[]) => {
    this.mapService.drawFeatures(districts);
    this.selectedRegionDistricts = districts;
  };

  onOpen(region: Region) {
    this.mapService.clearRegionsFeatures();
    this.router.navigate([region.districtGid], { relativeTo: this.activatedRoute });
  }

  ngOnDestroy() {
    this.mapService.clearRegionsFeatures();
  }
}
