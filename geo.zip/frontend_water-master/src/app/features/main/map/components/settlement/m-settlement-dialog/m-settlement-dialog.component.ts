import { Component } from '@angular/core';
import { SettlementDialog } from '../settlement.component';

@Component({
  selector: 'app-m-settlement-dialog',
  templateUrl: './m-settlement-dialog.component.html',
  styleUrls: ['./m-settlement-dialog.component.scss'],
})
export class MSettlementDialogComponent extends SettlementDialog {}
