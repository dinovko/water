import { Injectable } from '@angular/core';
import { Map, View, Feature, MapBrowserEvent } from 'ol';
import { Tile as TileLayer } from 'ol/layer';
import { TileWMS } from 'ol/source';
import { ApiConfig } from 'src/api.config';
import { constants } from 'src/app/сonstants';
import { getBottomLeft, Extent, getCenter } from 'ol/extent';
import { get as projGet } from 'ol/proj';
import { defaults, Select } from 'ol/interaction';
import { Region } from 'src/app/shared/models/mapInfo';
import { WKT } from 'ol/format';
import Geometry from 'ol/geom/Geometry';
//import * as jsPDF from 'jspdf';
import htmlToImage from 'html-to-image';
import { MatButton } from '@angular/material/button';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import Stroke from 'ol/style/Stroke';
import Fill from 'ol/style/Fill';
import Text from 'ol/style/Text';
import GeometryType from 'ol/geom/GeometryType';
import Style from 'ol/style/Style';
import { SelectEvent } from 'ol/interaction/Select';
import { Coordinate } from 'ol/coordinate';
import { Point, Circle } from 'ol/geom';
import Icon from 'ol/style/Icon';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject } from 'rxjs';
import { MainService } from '../main.service';
import OSM from 'ol/source/OSM';
@Injectable({
  providedIn: 'root',
})
export class MapService {
  map: Map = null;
  printTable = new BehaviorSubject(null);
  regionsVectorLyr: VectorLayer;
  selectedRegionVectorLyr: VectorLayer;
  select: Select;
  hoveredFeature: Feature = null;
  selectedFeature: Feature = null;
  isPoints = false;
  view = new View({
    extent: constants.map.extent,
    center: constants.map.center,
    zoom: constants.map.zoom,
    maxZoom: constants.map.maxZoom,
  });
  borderStyle = new Style({
    stroke: new Stroke({
      color: `#fff`,
      width: 5,
    }),
  });
  pointStyle = (feature: Feature, resolution) => {
    const region: Region = feature.get('data');
    if (!region) {
      return this.borderStyle;
    }
    const styleData: { imageColor; imageStyle?; textColor } = region.accessPopulation
      ? { imageColor: 'blue', textColor: '#0099EF' }
      : region.notAccessPopulationMore
      ? { imageColor: 'red', textColor: '#FF0000' }
      : { imageColor: 'brown', textColor: '#9D6C00' };

    styleData.imageStyle =
      (region.isSpecProject && region.isGroupFinance) > 0
        ? 'crownselected'
        : region.isSpecProject
        ? 'crown'
        : region.isGroupFinance
        ? 'selected'
        : 'simple';

    return [
      new Style({
        image: new Icon({
          src: `../../../../assets/map-icons/${styleData.imageColor}/${styleData.imageStyle}.png`,
          scale: 0.6,
        }),
        zIndex: 1,
        text:
          resolution > 2000
            ? null
            : new Text({
                textAlign: 'left',
                textBaseline: 'top',
                offsetX: 12,
                offsetY: -6,
                text: `${feature.get('name')}\n${region.population ??
                  0}/${region.accessPopulation ?? 0}`,
                font: `bold 12px Roboto,sans-serif`,
                fill: new Fill({
                  color: styleData.textColor,
                }),
                overflow: true,
              }),
      }),
      new Style({
        stroke: new Stroke({
          color: '#000',
          width: 6,
        }),
        zIndex: 6,
      }),
      new Style({
        fill: new Fill({ color: 'rgba(79, 79, 79, 0.05)' }),
        stroke: new Stroke({ color: 'rgba(79, 79, 79, 0.4)', width: 1 }),
        geometry: new Circle(feature.getGeometry()['getCoordinates'](), 3 * resolution),
      }),
    ];
  };

  defaultStyle = (feature, resolution) => {
    // такой сложный стиль потому что геометрия городов - разразненные полигоны,
    // проблема: на каждом полигоне возникает надпись
    // решение: отображать только одну надпись на самом большом
    // так же сюда добавил логику смены цветов при наведении и клике
    const polyStyleConfig: { stroke: Stroke; fill: Fill } = {
      stroke: new Stroke({
        color: `rgba(255, 255, 255, 1)`,
        width: 2,
      }),
      fill: new Fill({
        color: `rgba(13, 115, 150, ${
          feature.get('selected') ? '0.6' : feature.get('hovered') ? '0.4' : '0'
        })`,
      }),
    };
    const textStyleConfig = {
      text: new Text({
        text: resolution < 100000 ? feature.get('name') : '',
        font: 'bold 14px Roboto,sans-serif',
        fill: new Fill({
          color: '#333',
        }),
        stroke: new Stroke({
          color: '#fff',
          width: 6.5,
        }),
        overflow: true,
      }),
      geometry: polygon => {
        let retPoint;
        if (polygon.getGeometry().getType() === GeometryType.MULTI_POLYGON) {
          retPoint = this.getMaxPoly(polygon.getGeometry().getPolygons()).getInteriorPoint();
        } else if (polygon.getGeometry().getType() === GeometryType.POLYGON) {
          retPoint = polygon.getGeometry().getInteriorPoint();
        }
        return retPoint;
      },
    };
    const textStyle = new Style(textStyleConfig);
    const style = new Style(polyStyleConfig);
    return [style, textStyle];
  };

  constructor(private translate: TranslateService, private mainService: MainService) {}

  initMap() {
    this.map = new Map({
      target: 'map',
      layers: [this.getBaseLayer()],
      view: this.view,
      interactions: defaults({
        mouseWheelZoom: false,
        pinchZoom: false,
        dragPan: true,
        doubleClickZoom: true,
        pinchRotate: false,
      }),
    });

    this.regionsVectorLyr = new VectorLayer({
      declutter: true,
      source: new VectorSource(),
      zIndex: 2,
      style: this.defaultStyle,
    });
    this.selectedRegionVectorLyr = new VectorLayer({
      source: new VectorSource(),
      zIndex: 1,
      style: this.borderStyle,
    });
    this.map.addLayer(this.selectedRegionVectorLyr);
    this.map.addLayer(this.regionsVectorLyr);
  }

  getBaseLayer(): TileLayer {
    const src = new TileWMS({
      url: ApiConfig.geoserver,
      params: {
        FORMAT: 'image/png',
        STYLES: '',
        VERSION: '1.1.0',
        tiled: true,
        LAYERS: `${constants.geoserver.workSpace}:basemap`,
        exceptions: 'application/vnd.ogc.se_inimage',
        tilesOrigin: getBottomLeft(projGet('EPSG:3857').getExtent()).toString(),
      },
      projection: 'EPSG:3857',
      crossOrigin: 'anonymous',
    });

    const newLayer = new TileLayer({
      source: src,
      visible: true,
    });
    newLayer.set('name', 'basemap');
    return newLayer;
  }

  getBaseLayer2(): TileLayer {
    const src = new TileWMS({
      url: ApiConfig.geoserver,
      params: {
        FORMAT: 'image/png',
        STYLES: '',
        VERSION: '1.1.0',
        tiled: true,
        LAYERS: `${constants.geoserver.workSpace}:basemap_n`,
        exceptions: 'application/vnd.ogc.se_inimage',
        tilesOrigin: getBottomLeft(projGet('EPSG:3857').getExtent()).toString(),
      },
      projection: 'EPSG:3857',
      crossOrigin: 'anonymous',
    });

    const newLayer = new TileLayer({
      source: src,
      visible: true,
    });
    newLayer.set('name', 'basemap');
    return newLayer;
  }

  getOSMLayer(): TileLayer {
    let osm = new TileLayer({
      source: new OSM(),
    });
    return osm;
  }

  clearRegionsFeatures() {
    this.selectedFeature = null;
    this.hoveredFeature = null;
    this.map.un('pointermove', this.onPointerMove);
    this.select?.un('select', this.onSelect);
    if (this.regionsVectorLyr) {
      this.regionsVectorLyr.getSource().clear();
    }
    if (this.selectedRegionVectorLyr) {
      this.selectedRegionVectorLyr.getSource().clear();
    }
    if (this.select) {
      this.map.removeInteraction(this.select);
    }
  }

  getMaxPoly(polys) {
    const polyObj = polys.map(poly => {
      return { poly, area: poly.getArea() };
    });

    polyObj.sort((a, b) => a.area - b.area);
    return polyObj[polyObj.length - 1].poly;
  }

  onPointerMove = (evt: MapBrowserEvent) => {
    const hit = this.map.forEachFeatureAtPixel(evt.pixel, (feature: Feature, layer) => {
      if (this.hoveredFeature && this.hoveredFeature !== feature) {
        this.hoveredFeature.set('hovered', false);
        this.hoveredFeature = null;
      }

      if (feature && !this.isPoints) {
        this.hoveredFeature = feature;
        this.hoveredFeature.set('hovered', true);
      }
      return true;
    });

    if (hit) {
      this.map.getTargetElement().style.cursor = 'pointer';
    } else {
      this.map.getTargetElement().style.cursor = '';
    }
  };

  onSelect = (evt: SelectEvent) => {
    if (this.selectedFeature === evt.selected[0]) {
      return;
    }

    if (this.selectedFeature !== null) {
      this.selectedFeature?.set('selected', false);
      this.selectedFeature = null;
    }
    setTimeout(() => {
      if (evt.selected.length && evt.selected[0].get('data')) {
        this.selectedFeature = evt.selected[0];
        this.selectedFeature.set('selected', true);
        this.selectedFeature.set('popupCoordinates', evt.mapBrowserEvent.coordinate);
      }
    });
  };

  print(
    printBtn: MatButton,
    mapInfoPnl: any,
    diagramInfoPnl: any,
    pageFormat = constants.printMap.defaultFormat,
    resolution = constants.printMap.defaultResolution,
  ) {
    this.mainService.mapLoading.next(true);
    this.printTable.next('print'); // Печать таблицы Excel
    this.printTable = new BehaviorSubject('');
    this.printMap(printBtn, mapInfoPnl, pageFormat, resolution); //Печать карты PNG
    if (diagramInfoPnl) this.printDiagram(diagramInfoPnl); //Печать диаграммы PNG
  }

  printMap(
    printBtn: MatButton,
    mapInfoPnl: any,
    pageFormat = constants.printMap.defaultFormat,
    resolution = constants.printMap.defaultResolution,
  ) {
    printBtn.disabled = true; // TODO add progress

    let dim = constants.printMap.dims[pageFormat];
    let width = Math.round((dim[0] * resolution) / 25.4);
    let height = Math.round((dim[1] * resolution) / 25.4);
    let size = this.map.getSize();
    let viewResolution = this.map.getView().getResolution();

    this.map.once('rendercomplete', () => {
      setTimeout(() => {
        let mapCanvas = document.createElement('canvas');
        mapCanvas.width = width;
        mapCanvas.height = height;
        let mapContext = mapCanvas.getContext('2d');
        Array.prototype.forEach.call(
          document.querySelectorAll('.ol-layer canvas'),
          (canvas: HTMLCanvasElement) => {
            if (canvas.width > 0) {
              let opacity = (canvas.parentNode as any).style.opacity;
              mapContext.globalAlpha = opacity === '' ? 1 : Number(opacity);
              let transform = canvas.style.transform;
              // Get the transform parameters from the style's transform matrix
              let matrix = transform
                .match(/^matrix\(([^\(]*)\)$/)[1]
                .split(',')
                .map(Number);
              // Apply the transform to the export map context
              CanvasRenderingContext2D.prototype.setTransform.apply(mapContext, matrix);
              mapContext.drawImage(canvas, 0, 0);
            }
          },
        );

        // Save map as PNG
        let infoPnlTop = mapInfoPnl.style.top;
        let infoPnlLeft = mapInfoPnl.style.top;
        let infoPnlMaxHeight = mapInfoPnl.style.maxHeight;
        mapInfoPnl.style.top = '0px';
        mapInfoPnl.style.left = '0px';
        mapInfoPnl.style.maxHeight = 'none';
        htmlToImage
          .toPng(mapInfoPnl, {
            style: { 'background-color': '#f7f7f7' },
          })
          .then(dataUrl => {
            let imgPanel = document.createElement('img');
            imgPanel.src = dataUrl;
            const ctx = mapCanvas.getContext('2d');
            imgPanel.addEventListener('load', e => {
              ctx.drawImage(imgPanel, 15, 15);
              let fullImg = mapCanvas
                .toDataURL('image/png')
                .replace('image/png', 'image/octet-stream');
              let link = document.createElement('a');
              link.download = 'map_water.png';
              link.href = fullImg;
              link.click();
              mapInfoPnl.style.top = infoPnlTop;
              mapInfoPnl.style.left = infoPnlLeft;
              mapInfoPnl.style.maxHeight = infoPnlMaxHeight;
              this.mainService.mapLoading.next(false);

              // Reset original map size
              this.map.setSize(size);
              this.map.getView().setResolution(viewResolution);
              printBtn.disabled = false; // TODO remove progress
            });
          });
      }, 500);
    });

    // Set print size
    let printSize = [width, height];
    this.map.setSize(printSize);
    let scaling = Math.min(width / size[0], height / size[1]);
    this.map.getView().setResolution(viewResolution / scaling);
  }

  printMap2() {
    let exportOptions = {
      filter: function(element) {
        return element.className ? element.className.indexOf('ol-control') === -1 : true;
      },
    };
    this.map.once('rendercomplete', () => {
      htmlToImage.toPng(this.map.getTargetElement(), exportOptions).then(dataURL => {
        let link = document.createElement('a');
        link.download = 'map_water.png';
        link.href = dataURL;
        link.click();
      });
    });
    this.map.renderSync();
  }

  printDiagram(diagramPnl: any) {
    let diagramCanvas = document.createElement('canvas');
    diagramCanvas.width = diagramPnl.width;
    diagramCanvas.height = diagramPnl.height;

    // Save map as PNG
    htmlToImage.toPng(diagramPnl, { style: { 'background-color': 'white' } }).then(dataUrl => {
      let imgPanel = document.createElement('img');
      imgPanel.src = dataUrl;
      const ctx = diagramCanvas.getContext('2d');
      imgPanel.addEventListener('load', e => {
        ctx.drawImage(imgPanel, 0, 0);
        let fullImg = diagramCanvas
          .toDataURL('image/png')
          .replace('image/png', 'image/octet-stream');
        let link = document.createElement('a');
        link.download = 'diagram_water.png';
        link.href = fullImg;
        link.click();
      });
    });
  }

  public base64ToByteArray(base64Img) {
    var parts = base64Img.split(';base64,');
    var base64String = parts[1];
    try {
      var sliceSize = 1024;
      var byteCharacters = atob(base64String);
      var bytesLength = byteCharacters.length;
      var slicesCount = Math.ceil(bytesLength / sliceSize);
      var byteArrays = new Array(slicesCount);

      for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
        var begin = sliceIndex * sliceSize;
        var end = Math.min(begin + sliceSize, bytesLength);

        var bytes = new Array(end - begin);
        for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
          bytes[i] = byteCharacters[offset].charCodeAt(0);
        }
        byteArrays[sliceIndex] = new Uint8Array(bytes);
      }
      return byteArrays;
    } catch (e) {
      console.log("Couldn't convert to byte array: " + e);
      return undefined;
    }
  }

  /**
   * Строковый wkt конвертирует в geometry (openLayers)
   */
  public convetFromWkt = (wkt: string): Geometry => {
    const wktFormat = new WKT();
    const geometry: Geometry = wktFormat.readGeometry(wkt);
    return geometry;
  };

  public zoomToGeom(geom: Geometry | string) {
    const geometry: Geometry = geom instanceof Geometry ? geom : this.convetFromWkt(geom);
    this.selectedRegionVectorLyr.getSource().addFeature(new Feature({ geometry }));
    const extent: Extent = geometry.getExtent();

    const duration = constants.map.duration;
    this.map.getView().setMaxZoom(constants.map.regionMaxZoom);
    this.map.getView().fit(extent, {
      duration,
      callback: () => {
        const view = new View({
          extent: extent.map((coord, index, array) => {
            const coeff = index % 2 === 0 ? array[2] - array[0] : array[3] - array[1];
            return coord + coeff * 0.8 * (index > 1 ? 1 : -1);
          }) as Extent,
          center: getCenter(extent),
          zoom: this.map.getView().getZoom(),
          maxZoom: constants.map.regionMaxZoom,
        });
        this.map.setView(view);
      },
    });
  }

  setFullKzView() {
    const zoom: number = this.map.getView().getZoom();
    const center: Coordinate = this.map.getView()?.getCenter() ?? getCenter(constants.map.extent);
    this.map.setView(
      new View({
        extent: constants.map.extent,
        center,
        zoom,
      }),
    );

    this.map.getView().animate({
      duration: constants.map.duration,
      center: getCenter(constants.map.extent),
      zoom: constants.map.zoom,
    });
  }

  drawFeatures = (regions: Region[]) => {
    this.isPoints = regions.every(region => this.convetFromWkt(region.wkt) instanceof Point);
    this.map.on('pointermove', this.onPointerMove);
    this.select = new Select({ style: this.isPoints ? this.pointStyle : this.defaultStyle });
    this.map.addInteraction(this.select);
    this.select.on('select', this.onSelect);

    if (regions.some(region => region.wkt)) {
      this.regionsVectorLyr.getSource().addFeatures(
        regions
          .filter(region => region.wkt)
          .map(region => {
            const newfeature: Feature = new Feature({
              geometry: this.convetFromWkt(region.wkt),
            });
            let text = this.getFeatureLabel(region);
            newfeature.set('name', text);
            newfeature.set('data', region);
            if (newfeature.getGeometry() instanceof Point) {
              newfeature.setStyle(this.pointStyle);
            }
            return newfeature;
          }),
      );
    }
  };

  getFeatureLabel(region: Region): string {
    let text =
      region['regionName' + this.translate.instant('Ru')] ||
      region['regionName' + this.translate.instant('Kk')] ||
      region['districtName' + this.translate.instant('Ru')] ||
      region['districtName' + this.translate.instant('Kk')] ||
      region['settlementName' + this.translate.instant('Ru')] ||
      region['settlementName' + this.translate.instant('Kk')] ||
      '';
    text =
      text.includes('облысы') ||
      text.includes('область') ||
      text.includes('район') ||
      text.includes('ауданы')
        ? text.replace(/ /g, '\n').replace(/-/g, '\n')
        : text; // ставим отступы
    return text;
  }
}
