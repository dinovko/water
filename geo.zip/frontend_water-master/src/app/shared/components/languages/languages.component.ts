import { Component, ChangeDetectionStrategy, AfterViewInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-languages',
  templateUrl: './languages.component.html',
  styleUrls: ['./languages.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LanguagesComponent implements AfterViewInit {
  languages = [
    { name: 'Русский', value: 'ru', displayValue: 'РУ' },
    { name: 'Қазақша', value: 'kk', displayValue: 'ҚАЗ' },
    // { name: 'Qazaqsha', value: 'qz', displayValue: 'QAZ' },
  ];
  selectLang = localStorage.getItem('language') || 'ru';
  currentLanguage = this.languages.find(l => l.value === this.selectLang);

  constructor(private translateService: TranslateService) {
    // устанавливаем язык по умолчанию - русский
    translateService.use('ru');
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      // берем последний выбранный пользователем язык
      if (localStorage.getItem('language')) {
        this.translateService.use(this.selectLang);
      }
    });
  }

  onSelectLanguage(language: { name: string; value: string; displayValue: string }) {
    this.selectLang = language.value;
    this.currentLanguage = language;
    this.translateService.use(language.value);
    localStorage.setItem('language', this.selectLang);
  }
}
