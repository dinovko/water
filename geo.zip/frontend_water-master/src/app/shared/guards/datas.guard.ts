import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/api.config';
import { HttpClient } from '@angular/common/http';
import { AuthService } from 'src/app/auth/services/auth.service';
import { CurrentUser } from 'src/app/auth/services/current.service';

@Injectable({ providedIn: 'root' })
export class DatasGuard implements CanActivate {
  constructor(
    private auth: AuthService,
    private router: Router,
    private http: HttpClient,
    private currentUser: CurrentUser,
  ) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const access_token = localStorage.getItem('access_token');
    if (access_token) {
      const url = `${ApiConfig.waterApi}/users/?access_token=${access_token}`;
      return this.http
        .get(url)
        .toPromise()
        .then((user: any) => {
          const isAdmin = user.roles.filter(u => u.code === 'ADMIN');
          const isDatas = user.roles.filter(u => u.code === 'MODERATOR');
          if (isAdmin.length || isDatas.length) {
            this.currentUser.setUser(user);
            return true;
          } else {
            this.router.navigate(['/not-found']);
            return false;
          }
        });
    } else {
      this.router.navigate(['/provision']);
      return false;
    }
  }
}
