import { Pipe, PipeTransform } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { SpacesPipe } from './spaces.pipe';
@Pipe({
  name: 'nullableData',
})
export class NullableDataPipe implements PipeTransform {
  transform(value: any, suffix: string = ''): string {
    const numberPipe = new DecimalPipe('ru-KZ');
    const spacesPipe = new SpacesPipe();
    return value !== null && value !== undefined
      ? (typeof value === 'number' ? spacesPipe.transform(numberPipe.transform(value)) : value) +
          suffix
      : '—';
  }
}
