import { Pipe, PipeTransform } from '@angular/core';
import { Region } from '../models/mapInfo';

@Pipe({
  name: 'sortArray',
})
export class SortArrayPipe implements PipeTransform {
  transform(array: unknown[], sortByField?: string): unknown | Region[] {
    if (!sortByField) {
      // todo: somelogic
      return array.sort();
    } else {
      return array.sort((a, b) => a[sortByField]?.localeCompare(b[sortByField]));
    }
  }
}
