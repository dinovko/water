const publicApi = '/water-api/public';

export const ApiConfig = {
  api: '/water-api/api',
  waterApi: '/water-api',
  public: publicApi,
  geoserver: '/geoserver/mapwater/wms',
};
