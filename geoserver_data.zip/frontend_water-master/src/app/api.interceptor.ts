import { Injectable, Injector } from '@angular/core';
import { Location } from '@angular/common';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpClient,
  HttpErrorResponse,
  HttpParams,
} from '@angular/common/http';
import { Observable, Subject, throwError } from 'rxjs';
import { ApiConfig } from 'src/api.config';
import { tap, catchError, switchMap, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable()
export class RefreshTokenInterceptor implements HttpInterceptor {
  refreshTokenInProgress = false;
  tokenRefreshedSource = new Subject();
  tokenRefreshed$ = this.tokenRefreshedSource.asObservable();

  constructor(
    private injector: Injector,
    private router: Router,
    private matDialog: MatDialog,
    private _location: Location,
  ) {}

  addAuthHeader(request) {
    return request.clone({
      setHeaders: {
        Authorization: `Bearer ${localStorage.getItem('access_token')}`,
      },
    });
  }

  refreshToken(next: HttpHandler, request: HttpRequest<any>) {
    if (this.refreshTokenInProgress) {
      return new Observable(observer => {
        this.tokenRefreshed$.subscribe(() => {
          observer.next();
          observer.complete();
        });
      });
    } else {
      this.refreshTokenInProgress = true;

      return this.getNewTokens(next, request).pipe(
        tap(() => {
          this.refreshTokenInProgress = false;
          this.tokenRefreshedSource.next();
        }),
      );
    }
  }

  getNewTokens(next: HttpHandler, request: HttpRequest<any>): Observable<any> {
    const http = this.injector.get(HttpClient);
    const headers = {
      Authorization: 'Basic ' + btoa('water:water'),
      'Content-type': 'application/x-www-form-urlencoded',
    };
    const body = new HttpParams()
      .set('refresh_token', localStorage.getItem('refresh_token'))
      .set('grant_type', 'refresh_token');
    const url: string = `${ApiConfig.waterApi}/oauth/token`;
    return http
      .post<any>(url, body, { headers: headers })
      .pipe(
        map((newToken: any) => this.setTokens(newToken)),
        catchError((error: HttpErrorResponse) => {
          this.matDialog.closeAll();
          localStorage.clear();
          // this.router.navigate(['/signin']);
          return next.handle(request);
        }),
      );
  }

  setTokens(token: any): any {
    localStorage.setItem('access_token', token.access_token);
    localStorage.setItem('refresh_token', token.refresh_token);
    return token;
  }

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    if (request.url.includes('/water-api/') && !localStorage.getItem('access_token')) {
      return next.handle(request);
    }

    if (request.url.includes(ApiConfig.waterApi + '/oauth/token')) {
      return next.handle(request);
    }

    if (request.url.includes(ApiConfig.waterApi + '/public')) {
      return next.handle(request);
    }

    request = this.addAuthHeader(request);
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          return this.refreshToken(next, request).pipe(
            switchMap(() => {
              request = this.addAuthHeader(request);
              return next.handle(request);
            }),
            catchError(err => {
              if (this.matDialog) {
                this.matDialog.closeAll();
              }
              localStorage.clear();
              // todo: уведомить об ошибке
              this.router.navigate(['/']);

              return throwError(error);
              return next.handle(request);
            }),
          );
        } else if (error.status === 403) {
          alert('Нет доступа');
          this._location.back();
        }
        return throwError(error);
      }),
    );
  }
}
