import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import {
  GreetingComponent,
  MobileGreetingComponent,
} from './components/greeting/greeting.component';
import { LoginComponent } from './auth/components/login/login.component';
import { DatePipe, registerLocaleData } from '@angular/common';
import { UserInfoComponent } from './auth/components/user-info/user-info.component';
import localeRuKZ from '@angular/common/locales/ru-KZ';
import { RefreshTokenInterceptor } from './api.interceptor';
import { MMenuComponent } from './components/mobile/m-menu/m-menu.component';

@NgModule({
  declarations: [
    AppComponent,
    GreetingComponent,
    MobileGreetingComponent,
    LoginComponent,
    UserInfoComponent,
    MMenuComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: RefreshTokenInterceptor, multi: true },
    DatePipe,
    { provide: LOCALE_ID, useValue: 'ru-KZ' },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
registerLocaleData(localeRuKZ, 'ru-KZ');

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
