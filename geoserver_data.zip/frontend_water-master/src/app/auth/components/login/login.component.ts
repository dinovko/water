import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { User } from '../../user-interface';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  message: string;
  submitted = false;
  errorMsg;
  authorized;

  loading$: Observable<boolean> = this.auth.pending$;
  errorMessage$: Observable<any> = this.auth.errorMsg$;

  constructor(
    private auth: AuthService,
    private router: Router,
    public dialogRef: MatDialogRef<LoginComponent>,
  ) {
    this.authorized = this.auth.authorized.subscribe(result => {
      if (result) {
        this.dialogRef.close();
      }
    });
  }

  ngOnDestroy(): void {
    this.authorized.unsubscribe();
    this.auth.errorMsg$.next(null);
  }

  ngOnInit(): void {
    this.form = new FormGroup({
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required, Validators.minLength(3)]),
    });
    this.errorMsg = this.errorMessage$;
  }

  submit() {
    console.log(this.form);

    this.submitted = true;

    const user: User = {
      username: this.form.value.username,
      password: this.form.value.password,
    };

    this.auth.login(user);
    this.submitted = false;
  }
}
