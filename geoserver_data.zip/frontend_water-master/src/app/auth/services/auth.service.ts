import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { Token, User } from '../user-interface';
import { Observable, BehaviorSubject } from 'rxjs';
import { ApiConfig } from 'src/api.config';
import { tap } from 'rxjs/operators';
import { CurrentUser } from './current.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  pending$ = new BehaviorSubject<boolean>(false);
  errorMsg$ = new BehaviorSubject<string>(null);
  authorized = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient, private router: Router, private currentUser: CurrentUser) {}
  get token(): string {
    return '';
  }
  login(user: User) {
    this.pending$.next(true);
    const headers = {
      Authorization: 'Basic ' + btoa('water:water'),
      'Content-type': 'application/x-www-form-urlencoded',
    };
    const body = new HttpParams()
      .set('username', user.username)
      .set('password', user.password)
      .set('grant_type', 'password');
    this.http.post(`${ApiConfig.waterApi}/oauth/token`, body.toString(), { headers }).subscribe(
      (token: Token) => {
        this.pending$.next(false);
        this.errorMsg$.next(null);
        if (token) {
          this.authorized.next(true);
        }
        localStorage.setItem('access_token', token.access_token);
        localStorage.setItem('refresh_token', token.refresh_token);
        localStorage.setItem('username', user.username);
        this.checkUserAuthorities();
        this.router.navigate(['/provision']);
      },
      err => {
        this.authorized.next(false);
        this.pending$.next(false);
        if (err.error.error_description == 'User is disabled') {
          return this.errorMsg$.next('Учетная запись заблокирована');
        }
        return this.errorMsg$.next('Логин и пароль не совпадают');
      },
    );
  }

  getCurrentUser(): Observable<User> {
    const access_token = localStorage.getItem('access_token');
    const url = `${ApiConfig.waterApi}/users/?access_token=${access_token}`;
    return this.http.get<User>(url);
  }

  public checkUserAuthorities(): void {
    this.getCurrentUser()
      .toPromise()
      .then((user: any) => {
        this.currentUser.setUser(user);
      });
  }
}
