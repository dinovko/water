import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AdminService } from './admin.service';
import Filter from 'ol/format/filter/Filter';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NotificationDialogComponent } from 'src/app/shared/components/notification-dialog/notification-dialog.component';

export interface User {
  id: number;
  fio: string;
  iin: string;
  userName: string;
  roles: { nameRu: string; code: string; id: number }[];
  status: string;
  systems: string[];
  organizations: string[];
  delete: string;
  email: string;
  newPassword?: string;
  newPassword2?: string;
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
})
export class AdminComponent implements OnInit {
  displayedColumns: string[] = [
    'fio',
    'iin',
    'organizations',
    'userName',
    'roles',
    'systems',
    'status',
    'delete',
  ];
  userStatus = false;
  btnActive = false;
  removeUserById;
  loading = true;
  public roles: { nameRu: string; code: string; id: number }[] = [];
  public statuses: { nameRu: string }[] = [];
  public organizations: { nameRu: string }[] = [];
  public systems: { nameRu: string }[] = [];
  dataSource = new MatTableDataSource();
  form: FormGroup;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private matDialog: MatDialog,
    private fb: FormBuilder,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
  ) {}

  ngOnInit() {
    this.getAllRoles();
    this.getAllUsers();
    this.getAllStatuses();
    this.getAllOrganizations();
    this.getAllSystems();
  }

  initForm(user: User) {
    let fio = [];
    if (user == null) {
      this.form = this.fb.group({
        secondName: this.fb.control(''),
        firstName: this.fb.control(''),
        middleName: this.fb.control(''),
        fio: this.fb.control(''),
        iin: this.fb.control('', [Validators.required, Validators.pattern(/^(\d{12})$/)]),
        email: this.fb.control('', [Validators.required, Validators.email]),
        roles: this.fb.control(''),
        systems: this.fb.control(''),
        status: this.fb.control(''),
        organizations: this.fb.control(''),
        userName: this.fb.control(''),
        newPassword: this.fb.control('', [Validators.required, Validators.minLength(3)]),
        newPassword2: this.fb.control('', [Validators.required, Validators.minLength(3)]),
      });
    } else {
      if ('string' === typeof user.fio) {
        fio = user.fio.split(' ');
      }
      this.form = this.fb.group({
        secondName: this.fb.control(fio[0]),
        firstName: this.fb.control(fio[1]),
        middleName: this.fb.control(fio[2]),
        iin: this.fb.control(user.iin, [Validators.required, Validators.pattern(/^(\d{12})$/)]),
        userName: this.fb.control(user.userName),
        roles: this.fb.control(user.roles),
        id: this.fb.control(user.id),
        systems: this.fb.control(user.systems),
        status: this.fb.control(user.status),
        organizations: this.fb.control(user.organizations),
        email: this.fb.control(user.email, [Validators.required, Validators.email]),
        // newPassword: this.fb.control(user.newPassword),
        // newPassword2: this.fb.control(user.newPassword2),
      });
    }
  }

  compareCategoryObjects(object1: any, object2: any) {
    return object1 && object2 && object1.id == object2.id;
  }

  openDialog(modal: any) {
    this.userStatus = true;
    this.btnActive = true;
    this.initForm(null);
    this.matDialog
      .open(modal, {
        maxHeight: '85vh',
        minHeight: '35vh',
        minWidth: '30vw',
        maxWidth: '60vw',
        panelClass: ['dialog_withoutPadding'],
      })
      .afterClosed()
      .toPromise()
      .then(() => {});
  }

  changePass(modal: any, element) {
    this.initForm(element);
    this.userStatus = false;
    this.btnActive = false;
    this.matDialog
      .open(modal, {
        maxHeight: '80vh',
        minHeight: '35vh',
        minWidth: '30vw',
        maxWidth: '60vw',
        panelClass: ['dialog_withoutPadding'],
      })
      .afterClosed()
      .toPromise()
      .then(() => {});
  }

  editUser() {
    this.form.value.fio =
      this.form.value.lastName + ' ' + this.form.value.firstName + ' ' + this.form.value.secondName;
    delete this.form.value.fio;
    delete this.form.value.newPassword2;
    this.form.value.newPassword = '';
    let body: User = this.form.value;
    this.adminService
      .editUser(body)
      .toPromise()
      .then((data: any) => {
        this.getAllUsers();
        let result = 'Пользователь успешно изменен';
        let status = 'Запрос на изменение';
        this.result('modal', result, 'success', status);
      })
      .catch(err => {
        let result = 'Ошибка';
        let status = 'Запрос на изменение';
        this.result('modal', result, 'error', status);
      });
  }

  removeOpenDialog(modal: any, element) {
    this.removeUserById = element.id;
    this.matDialog.open(modal, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
    });
  }

  removeUser(status) {
    if (status === 1) {
      this.adminService
        .delete(this.removeUserById)
        .toPromise()
        .then((dataStatus: any) => {
          this.getAllUsers();
          let result = 'Пользователь успешно удален';
          let status = 'Запрос на удаление';
          this.result('modal', result, 'success', status);
        })
        .catch(err => {
          let result = 'Ошибка';
          let status = 'Запрос на удаление';
          this.result('modal', result, 'error', status);
        });
    } else {
    }
  }

  createUser() {
    debugger;
    if (this.form.value.newPassword === this.form.value.newPassword2) {
      this.form.value.fio =
        this.form.value.secondName +
        ' ' +
        this.form.value.firstName +
        ' ' +
        this.form.value.middleName;
      delete this.form.value.fio;
      delete this.form.value.newPassword2;
      if (!this.form.value.organizations) {
        this.form.value.organizations = [];
      }
      let body: User = this.form.value;
      this.adminService
        .addUser(body)
        .toPromise()
        .then((data: any) => {
          this.getAllUsers();
          let result = 'Пользователь успешно добавлен';
          let status = 'Запрос на добавление';
          this.result('modal', result, 'success', status);
        })
        .catch(err => {
          let result = 'Ошибка';
          let status = 'Запрос на добавление';
          this.result('modal', result, 'error', status);
        });
    } else {
      let result = 'Пароли не совпадают. Повторите попытку.';
      let status = 'Запрос на добавление';
      this.result('modal', result, 'error', status);
    }
  }

  getAllRoles() {
    this.adminService
      .getAllRoles()
      .toPromise()
      .then(allRoles => {
        this.roles = allRoles;
      });
  }

  getAllUsers() {
    this.loading = false;
    setTimeout(() => {
      this.adminService
        .getAllUsers()
        .toPromise()
        .then(allUsers => {
          allUsers.forEach(element => {
            element.fio = element.secondName + ' ' + element.firstName + ' ' + element.middleName;
          });
          console.log('AllUsers', allUsers);
          this.dataSource = new MatTableDataSource(allUsers);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.loading = true;
        });
    }, 3000);
  }

  getAllSystems() {
    this.adminService
      .getAllSystems()
      .toPromise()
      .then(allSystems => {
        this.systems = allSystems;
      });
  }

  getAllStatuses() {
    this.adminService
      .getAllStatuses()
      .toPromise()
      .then(allStatuses => {
        this.statuses = allStatuses;
      });
  }

  getAllOrganizations() {
    this.adminService
      .getAllOrganizations()
      .toPromise()
      .then(allOrganizations => {
        this.organizations = allOrganizations;
      });
  }

  result(modal: any, result, res, status) {
    this.matDialog.open(NotificationDialogComponent, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
      data: { result, res, status },
    });
  }
}
