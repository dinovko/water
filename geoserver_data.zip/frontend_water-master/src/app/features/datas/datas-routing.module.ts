import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DatasComponent } from './datas.component';
import { DatasGuard } from 'src/app/shared/guards/datas.guard';

const routes: Routes = [
  {
    path: '',
    component: DatasComponent,
    canActivate: [DatasGuard],
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DatasRoutingModule {}
