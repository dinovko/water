export class Settlement {
  gid: number;
  nameRu: string;
  nameKk: string;
  population: number;
  gidDistrict: number;
  settlementWater: SettlementWater;
}
export class SettlementWater {
  id: number;
  financeSettlementWaters: Array<FinanceSettlementWaters> = [];
  serviceCompany: string;
  amountGetWaterSupply: number;
  amountAllIndividualRecord: number;
  totalLengthWaterPipes: number;
  outwornLengthWaterPipes: number;
  deterioration: number;
  tariffsWaterSupply: number;
  needRbKds: number;
  needRbKvr: number;
  needLb: number;
  availabilityDed: string;
  dicWaterSource: any;
  explorationWork: string;
  accessWatersupplyPopulation: number;
  serviceCompanyAddress: string;
  serviceCompanyPhone: string;
  tariffPopulation: number;
  tariffCost: number;
  tariffSubsidy: number;
  needImplementationFrom: string;
  needImplementationTo: string;
  lengthOwnerlessPipes: number;
  isSpecProject: number;
  unitTariff: 'м³' | 'за 1 чел.';
  isGroupFinance: number;
}
export class FinanceSettlementWaters {
  id: number;
  dicFinanceType: any;
  projectName: string;
  financeRbKvr: number;
  financeRbKds: number;
  financeLb: number;
  implementationFrom: string;
  implementationTo: string;
  finishDate: string;
  index: number;
  edit: string;
}
export class newRequestFinance {
  id: number;
  dicFinanceType: any;
  projectName: string;
  financeRbKvr: number;
  financeRbKds: number;
  financeLb: number;
  implementationFrom: string;
  implementationTo: string;
  finishDate: string;
  edit: string;
  index: number;
}
