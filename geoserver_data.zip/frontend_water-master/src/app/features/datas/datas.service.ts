import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { ApiConfig } from 'src/api.config';

@Injectable({
  providedIn: 'root',
})
export class DatasService {
  constructor(private http: HttpClient) {}
  getRegion(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/allRegions`);
  }
  getDistricts(id): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/districts-byRegion/${id}`);
  }
  getSettlements(id): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/settlements-byDistrict/${id}`);
  }
  getSettlementsData(id): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/settlement/${id}`);
  }

  createNewDatas(body: any): Observable<any> {
    const formData = new FormData();
    formData.append('settlementStr', JSON.stringify(body));
    return this.http.post(`${ApiConfig.waterApi}/water-supply/updateSettlement`, formData);
  }
  allWaterSources(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/allWaterSources`);
  }
  allFinanceTypes(): Observable<any> {
    return this.http.get(`${ApiConfig.waterApi}/public/common/allFinanceTypes`);
  }

  addSettlement(districtId: number, wkt: string): Observable<any> {
    return this.http.put(
      `${ApiConfig.waterApi}/water-supply/settlement/${districtId}/${wkt}`,
      null,
    );
  }
  updateSettlement(id, wkt: string): Observable<any> {
    return this.http.post(`${ApiConfig.waterApi}/water-supply/settlement/${id}/${wkt}`, null);
  }
  deleteSettlement(id): Observable<any> {
    return this.http.delete(`${ApiConfig.waterApi}/water-supply/settlement/${id}`);
  }

  deleteFinance(id): Observable<any> {
    return this.http.delete(`${ApiConfig.waterApi}/water-supply/finance/${id}`);
  }
  removeSettlement(id): Observable<any> {
    return this.http.delete(`${ApiConfig.waterApi}/water-supply/${id}`);
  }
}
