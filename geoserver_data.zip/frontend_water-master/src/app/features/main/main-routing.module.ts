import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main.component';
import { ProvisionComponent } from './provision/provision.component';
import { FinanceComponent } from './finance/finance.component';
import { NeedsComponent } from './needs/needs.component';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';
import { FullKzComponent } from './map/components/full-kz/full-kz.component';
import { RegionComponent } from './map/components/region/region.component';
import { DistrictComponent } from './map/components/district/district.component';
import { SettlementComponent } from './map/components/settlement/settlement.component';
import { FullKzFinanceComponent } from './map/components/full-kz/full-kz-finance.component';
import { RegionFinanceComponent } from './map/components/region/region.component-finance';
import { DistrictFinanceComponent } from './map/components/district/district-finance.component';
import { FullKzNeedsComponent } from './map/components/full-kz/full-kz-needs.component';
import { RegionNeedsComponent } from './map/components/region/region.component-needs';
import { DistrictNeedsComponent } from './map/components/district/district-needs.component';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      { path: '', redirectTo: '/provision', pathMatch: 'full' },
      {
        path: 'provision',
        component: ProvisionComponent,
        children: [
          { path: '', component: FullKzComponent },
          { path: ':regionid', component: RegionComponent },
          {
            path: ':regionid/:districtid',
            component: DistrictComponent,
            children: [{ path: ':settlementid', component: SettlementComponent }],
          },
        ],
      },
      {
        path: 'finance',
        component: FinanceComponent,
        canActivate: [AuthGuard],
        children: [
          { path: '', component: FullKzFinanceComponent },
          { path: ':regionid', component: RegionFinanceComponent },
          {
            path: ':regionid/:districtid',
            component: DistrictFinanceComponent,
            children: [{ path: ':settlementid', component: SettlementComponent }],
          },
        ],
      },
      {
        path: 'needs',
        component: NeedsComponent,
        children: [
          { path: '', component: FullKzNeedsComponent },
          { path: ':regionid', component: RegionNeedsComponent },
          {
            path: ':regionid/:districtid',
            component: DistrictNeedsComponent,
            children: [{ path: ':settlementid', component: SettlementComponent }],
          },
        ],
      },
    ],
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainRoutingModule {}
