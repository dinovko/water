import { Component, OnDestroy, OnInit } from '@angular/core';
import { MainService } from './main.service';
import { Router, RouterEvent, NavigationEnd } from '@angular/router';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { CurrentUser } from 'src/app/auth/services/current.service';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { constants } from 'src/app/сonstants';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
})
export class MainComponent implements OnDestroy {
  activeRouteIndex: number;
  activatedUrl: string;
  subscription: Subscription = new Subscription();
  role;
  constructor(private router: Router, private _user: CurrentUser, public mainService: MainService) {
    const roleSubscr = _user.user$.subscribe(data => {
      if (data) {
        this.tabs[1].role = true;
      } else {
        this.tabs[1].role = false;
      }
    });
    this.subscription.add(roleSubscr);
    const routeSubscr = router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((r: RouterEvent) => {
        this.activeRouteIndex = this.tabs
          .filter(route => route.role)
          .findIndex(tab => r.url.startsWith('/' + tab.route));
        this.activatedUrl = r.url;
      });
    this.subscription.add(routeSubscr);
  }

  tabs: { label: string; route: string; iconClass: string; role: any }[] = constants.mainTabs;

  routeNavigate(event: MatTabChangeEvent) {
    this.activeRouteIndex = event.index;
    const urlPreffix =
      this.activatedUrl.indexOf('/', 1) > -1
        ? this.activatedUrl.substring(this.activatedUrl.indexOf('/', 1))
        : '';
    this.router.navigate([
      this.tabs.filter(route => route.role)[this.activeRouteIndex].route + urlPreffix.split('?')[0],
    ]);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
