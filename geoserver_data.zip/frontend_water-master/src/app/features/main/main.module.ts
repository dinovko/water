import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainRoutingModule } from './main-routing.module';
import { MainComponent } from './main.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { MapComponent } from './map/map.component';
import { FinanceComponent } from './finance/finance.component';
import { ProvisionComponent } from './provision/provision.component';
import { NeedsComponent } from './needs/needs.component';
import { FullKzComponent } from './map/components/full-kz/full-kz.component';
import { FullKzFinanceComponent } from './map/components/full-kz/full-kz-finance.component';
import { FullKzNeedsComponent } from './map/components/full-kz/full-kz-needs.component';
import {
  MapPopupComponent,
  MapPopupNeedsComponent,
  MapPopupFinanceComponent,
} from './map/components/map-popup/map-popup.component';
import { RegionComponent } from './map/components/region/region.component';
import { RegionFinanceComponent } from './map/components/region/region.component-finance';
import { RegionNeedsComponent } from './map/components/region/region.component-needs';
import {
  MapInfoComponent,
  MapInfoFinanceComponent,
  MapInfoNeedsComponent,
} from './map/components/map-info/map-info.component';
import { DistrictComponent } from './map/components/district/district.component';
import { DistrictFinanceComponent } from './map/components/district/district-finance.component';
import { DistrictNeedsComponent } from './map/components/district/district-needs.component';
import {
  SettlementComponent,
  SettlementDialog,
} from './map/components/settlement/settlement.component';
import { MBreadCrumbsComponent } from './map/components/m-bread-crumbs/m-bread-crumbs.component';
import { DiagramComponent } from './map/components/diagram/diagram.component';
import { TableComponent } from './map/components/table/table.component';
import { MapPopupSettlementComponent } from './map/components/map-popup/map-popup-settlement/map-popup-settlement.component';
import { MSettlementDialogComponent } from './map/components/settlement/m-settlement-dialog/m-settlement-dialog.component';
import { MapInfoDialogComponent } from './map/components/map-info/map-info-dialog/map-info-dialog.component';

@NgModule({
  declarations: [
    MainComponent,
    MapComponent,
    ProvisionComponent,
    FinanceComponent,
    NeedsComponent,
    FullKzComponent,
    FullKzFinanceComponent,
    FullKzNeedsComponent,
    MapPopupComponent,
    MapPopupFinanceComponent,
    MapPopupNeedsComponent,
    RegionComponent,
    RegionFinanceComponent,
    RegionNeedsComponent,
    MapInfoComponent,
    MapInfoFinanceComponent,
    MapInfoNeedsComponent,
    DistrictComponent,
    DistrictFinanceComponent,
    DistrictNeedsComponent,
    SettlementComponent,
    MBreadCrumbsComponent,
    SettlementDialog,
    DiagramComponent,
    TableComponent,
    MapPopupSettlementComponent,
    MSettlementDialogComponent,
    MapInfoDialogComponent,
  ],
  imports: [CommonModule, MainRoutingModule, SharedModule],
  entryComponents: [SettlementDialog, MapInfoDialogComponent],
})
export class MainModule {}
