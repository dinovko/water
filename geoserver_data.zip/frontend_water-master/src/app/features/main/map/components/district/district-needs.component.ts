import { Component } from '@angular/core';
import { DistrictComponent } from './district.component';

@Component({
  selector: 'app-district-needs',
  template: `
    <div class="map-info" *ngIf="districtData && !mainService.mobileQuery?.matches">
      <app-map-info-needs [data]="districtData"></app-map-info-needs>
    </div>
    <app-map-popup-settlement
      *ngIf="mapService.selectedFeature"
      [coordinates]="mapService.selectedFeature?.get('popupCoordinates')"
      [data]="mapService.selectedFeature?.get('data')"
      (opened)="onOpen($event)"
      [dataType]="'needs'"
    ></app-map-popup-settlement>
    <mat-tab-group *ngIf="!mainService.mobileQuery?.matches">
      <mat-tab label="Диаграмма">
        <app-diagram
          *ngIf="selectedDistrictCitiesTable?.length"
          [inputData]="selectedDistrictCitiesTable"
          [displayName]="'settlementName' + ('Ru' | translate)"
          [diagramType]="'needs'"
        ></app-diagram>
      </mat-tab>
      <mat-tab label="Таблица">
        <app-table
          *ngIf="selectedDistrictCitiesTable?.length"
          [inputData]="selectedDistrictCitiesTable"
          [tableType]="'needs'"
        ></app-table>
      </mat-tab>
    </mat-tab-group>
    <app-m-bread-crumbs
      *ngIf="selectedDistrictCities?.length && mainService.mobileQuery?.matches && districtData"
      [data]="selectedDistrictCities"
      [mapInfo]="districtData"
    ></app-m-bread-crumbs>
    <router-outlet></router-outlet>
  `,
})
export class DistrictNeedsComponent extends DistrictComponent {}
