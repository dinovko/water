import { Component, AfterViewInit, OnDestroy } from '@angular/core';
import { MapService } from 'src/app/features/main/map/map.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MainService } from 'src/app/features/main/main.service';
import { Region } from 'src/app/shared/models/mapInfo';
import { RegionsService } from 'src/app/shared/services/regions.service';

@Component({
  selector: 'app-district',
  template: `
    <div class="map-info" *ngIf="districtData && !mainService.mobileQuery?.matches">
      <app-map-info [data]="districtData"></app-map-info>
    </div>
    <app-map-popup-settlement
      *ngIf="mapService.selectedFeature"
      [coordinates]="mapService.selectedFeature?.get('popupCoordinates')"
      [data]="mapService.selectedFeature?.get('data')"
      (opened)="onOpen($event)"
    ></app-map-popup-settlement>
    <app-table
      *ngIf="selectedDistrictCities?.length && !mainService.mobileQuery?.matches"
      [inputData]="selectedDistrictCities"
      [tableType]="'potrebnost'"
    ></app-table>
    <app-m-bread-crumbs
      *ngIf="selectedDistrictCities?.length && mainService.mobileQuery?.matches && districtData"
      [data]="selectedDistrictCities"
      [mapInfo]="districtData"
    ></app-m-bread-crumbs>
    <router-outlet></router-outlet>
  `,
})
export class DistrictComponent implements AfterViewInit, OnDestroy {
  regionGid = this.activatedRoute.snapshot.params.regionid;
  districtGid = this.activatedRoute.snapshot.params.districtid;
  districtData: Region;
  selectedDistrictCities: Region[];
  selectedDistrictCitiesTable: Region[];
  constructor(
    public regionsService: RegionsService,
    public mapService: MapService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public mainService: MainService,
  ) {}

  ngAfterViewInit(): void {
    if (!this.regionsService.districts || this.regionsService.districts.length === 0) {
      setTimeout(() => {
        this.regionsService.getDistricts(this.regionGid, this.getDistrictDataAndZoom);
      });
    } else {
      setTimeout(() => {
        this.getDistrictDataAndZoom(this.regionsService.districts);
      });
    }
  }

  getDistrictDataAndZoom = (districts: Region[]) => {
    // tslint:disable-next-line: triple-equals
    this.districtData = districts.find(district => district.districtGid == this.districtGid);
    this.mapService.zoomToGeom(this.districtData.wkt);

    this.selectedDistrictCities = this.regionsService.cities.filter(
      // tslint:disable-next-line: triple-equals
      (city: Region) => city.districtGid == this.districtData.districtGid,
    );
    this.selectedDistrictCitiesTable = this.regionsService.citiesTable.filter(
      // tslint:disable-next-line: triple-equals
      (city: Region) => city.districtGid == this.districtData.districtGid,
    );
    if (this.regionsService.cities.length === 0 || !this.selectedDistrictCities?.length) {
      this.regionsService.getCities(this.districtData.districtGid, this.drawFeatures);
      this.regionsService.getCitiesTable(this.districtData.districtGid, this.drawFeaturesTable);
    } else {
      this.drawFeatures(this.selectedDistrictCities);
      this.drawFeaturesTable(this.selectedDistrictCitiesTable);
    }
  };

  drawFeatures = (cities: Region[]) => {
    this.mapService.drawFeatures(cities);
    this.selectedDistrictCities = cities;
  };
  drawFeaturesTable = (cities: Region[]) => {
    this.selectedDistrictCitiesTable = cities;
  };
  ngOnDestroy() {
    this.mapService.clearRegionsFeatures();
  }

  onOpen(region: Region) {
    // this.mapService.clearRegionsFeatures();
    this.router.navigate([region.settlementGid], { relativeTo: this.activatedRoute }); //, region.regionGid]);
  }
}
