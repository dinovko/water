import { Component } from '@angular/core';
import { FullKzComponent } from './full-kz.component';

@Component({
  selector: 'app-full-kz-needs',
  template: `
    <app-map-popup-needs
      *ngIf="mapService.selectedFeature && !mainService.mobileQuery?.matches"
      [coordinates]="mapService.selectedFeature?.get('popupCoordinates')"
      [data]="mapService.selectedFeature?.get('data')"
      (opened)="onOpen($event)"
    ></app-map-popup-needs>
    <div class="map-info" *ngIf="!mainService.mobileQuery?.matches">
      <app-map-info-needs *ngIf="regionsService.fullInfoKz"></app-map-info-needs>
    </div>
    <mat-tab-group *ngIf="!mainService.mobileQuery?.matches">
      <mat-tab label="Диаграмма">
        <app-diagram
          *ngIf="regionsService.regions?.length"
          [inputData]="regionsService.regions"
          [displayName]="'regionName' + ('Ru' | translate)"
          [diagramType]="'needs'"
        ></app-diagram>
      </mat-tab>
      <mat-tab label="Таблица">
        <app-table
          *ngIf="regionsService.regions?.length"
          [inputData]="regionsService.regions"
          [tableType]="'needs'"
        ></app-table>
      </mat-tab>
    </mat-tab-group>
    <app-m-bread-crumbs
      *ngIf="
        regionsService.regions?.length &&
        mainService.mobileQuery?.matches &&
        regionsService.fullInfoKz
      "
      [data]="regionsService.regions"
      [mapInfo]="regionsService.fullInfoKz"
    ></app-m-bread-crumbs>
  `,
})
export class FullKzNeedsComponent extends FullKzComponent {}
