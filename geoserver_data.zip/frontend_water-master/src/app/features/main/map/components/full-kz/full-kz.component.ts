import { Component, AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { Feature, MapBrowserEvent } from 'ol';
import Style from 'ol/style/Style';
import Fill from 'ol/style/Fill';
import Stroke from 'ol/style/Stroke';
import Text from 'ol/style/Text';
import GeometryType from 'ol/geom/GeometryType';
import { Select } from 'ol/interaction';
import { SelectEvent } from 'ol/interaction/Select';
import { Router, ActivatedRoute } from '@angular/router';
import { Region } from 'src/app/shared/models/mapInfo';
import { MapService } from 'src/app/features/main/map/map.service';
import { MainService } from 'src/app/features/main/main.service';
import { RegionsService } from 'src/app/shared/services/regions.service';

@Component({
  selector: 'app-full-kz',
  template: `
    <app-map-popup
      *ngIf="mapService.selectedFeature && !mainService.mobileQuery?.matches"
      [coordinates]="mapService.selectedFeature?.get('popupCoordinates')"
      [data]="mapService.selectedFeature?.get('data')"
      (opened)="onOpen($event)"
    ></app-map-popup>
    <div class="map-info" *ngIf="!mainService.mobileQuery?.matches">
      <app-map-info *ngIf="regionsService.fullInfoKz"></app-map-info>
    </div>
    <app-table
      *ngIf="regionsService.regions?.length && !mainService.mobileQuery?.matches"
      [inputData]="regionsService.regions"
      [tableType]="'potrebnost'"
    ></app-table>
    <app-m-bread-crumbs
      *ngIf="
        regionsService.regions?.length &&
        mainService.mobileQuery?.matches &&
        regionsService.fullInfoKz
      "
      [data]="regionsService.regions"
      [mapInfo]="regionsService.fullInfoKz"
    ></app-m-bread-crumbs>
  `,
})
export class FullKzComponent implements AfterViewInit, OnDestroy {
  constructor(
    public mapService: MapService,
    public regionsService: RegionsService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public mainService: MainService,
  ) {}

  ngAfterViewInit() {
    if (!this.regionsService.fullInfoKz) {
      this.regionsService.getFullInfoKz();
    }

    setTimeout(() => {
      if (this.regionsService.regions?.length) {
        this.mapService.drawFeatures(this.regionsService.regions);
      } else {
        this.regionsService.getRegions(this.mapService.drawFeatures);
      }
      this.mapService.setFullKzView();
    });
  }

  onOpen(region: Region) {
    this.mapService.clearRegionsFeatures();
    this.router.navigate([region.regionGid], { relativeTo: this.activatedRoute }); //, region.regionGid]);
  }

  ngOnDestroy() {
    this.mapService.clearRegionsFeatures();
  }
}
