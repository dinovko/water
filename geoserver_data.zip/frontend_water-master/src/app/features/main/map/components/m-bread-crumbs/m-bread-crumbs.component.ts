import { Component, Input, AfterViewInit, NgZone } from '@angular/core';
import { ActivatedRoute, Router, ActivatedRouteSnapshot } from '@angular/router';
import { MapService } from 'src/app/features/main/map/map.service';
import { MatDialog } from '@angular/material/dialog';
import { MapInfoDialogComponent } from '../map-info/map-info-dialog/map-info-dialog.component';
import { Region } from 'src/app/shared/models/mapInfo';
import { RegionsService } from 'src/app/shared/services/regions.service';
@Component({
  selector: 'app-m-bread-crumbs',
  templateUrl: './m-bread-crumbs.component.html',
  styleUrls: ['./m-bread-crumbs.component.scss'],
})
export class MBreadCrumbsComponent {
  @Input() data: Region[];
  @Input() mapInfo: Region[];
  regionGid = this.activatedRoute.snapshot.params.regionid;
  districtGid = this.activatedRoute.snapshot.params.districtid;
  isSettlement: boolean = this.activatedRoute.snapshot.children.some(
    (childRoute: ActivatedRouteSnapshot) => childRoute.params.settlementid,
  );
  selectedInPreviousRoute: boolean = this.activatedRoute.snapshot.queryParams[
    'selectedInPreviousRoute'
  ];

  selectedRegion: Region;
  selectedDistrict: Region;
  dataType: 'provision' | 'finance' | 'needs' | string = '';

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public regionsService: RegionsService,
    private matDialog: MatDialog,
    private ngZone: NgZone,
  ) {
    const firstPartOfRoute = router.url.split('/').filter(urlPart => urlPart)[0] ?? '';
    const withoutQueryparams = firstPartOfRoute.split('?')[0];
    this.dataType = withoutQueryparams;

    if (!this.regionsService.regions?.length && this.regionGid) {
      this.regionsService.getRegions(this.setRegion);
    } else {
      this.setRegion(this.regionsService.regions);
    }

    if (!this.regionsService.districts?.length && this.districtGid) {
      this.regionsService.getDistricts(this.districtGid, this.setDistrict);
    } else {
      this.setDistrict(this.regionsService.districts);
    }

    if (this.selectedInPreviousRoute || this.isSettlement) {
      return;
    }

    setTimeout(() => {
      this.showMapInfo();
    });
  }

  setRegion = regions => {
    this.selectedRegion = regions?.find((region: Region) => region.regionGid == this.regionGid);
  };

  setDistrict = districts => {
    this.selectedDistrict = districts?.find(
      (district: Region) => district.districtGid == this.districtGid,
    );
  };

  showMapInfo(dataType = this.dataType) {
    this.matDialog.open(MapInfoDialogComponent, {
      maxHeight: '90vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '90vw',
      data: { ...this.mapInfo, dataType },
      panelClass: 'm-map-info',
      autoFocus: false,
    });
  }

  ngZoneNavigate(routeArray, queryParams?) {
    this.ngZone.run(() => this.router.navigate(routeArray, { queryParams }).then());
  }
}
