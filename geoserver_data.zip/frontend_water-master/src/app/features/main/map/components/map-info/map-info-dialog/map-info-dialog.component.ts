import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Region } from 'src/app/shared/models/mapInfo';

@Component({
  selector: 'app-map-info-dialog',
  templateUrl: './map-info-dialog.component.html',
  styleUrls: ['./map-info-dialog.component.scss'],
})
export class MapInfoDialogComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: Region, private matDialog: MatDialog) {
    if (!data.regionNameRu && !data.districtNameRu) {
      data.regionNameRu = 'Республика Казахстан';
      data.regionNameKk = 'Қазақстан Республикасы';
    }
  }

  onNavigated() {
    this.matDialog.closeAll();
  }
}
