import { Component, OnInit, Input, OnChanges, Output, EventEmitter, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { Region } from 'src/app/shared/models/mapInfo';
import { RegionsService } from 'src/app/shared/services/regions.service';

@Component({
  selector: 'app-map-info',
  templateUrl: './map-info.component.html',
  styleUrls: ['./map-info.component.scss'],
})
export class MapInfoComponent implements OnInit, OnChanges {
  constructor(
    private regionsService: RegionsService,
    private router: Router,
    private ngZone: NgZone,
  ) {}

  @Input() data: Region = {
    ...this.regionsService.fullInfoKz,
    regionNameKk: 'Қазақстан Республикасы',
    regionNameRu: 'Республика Казахстан',
  };

  @Output() navigated = new EventEmitter();

  ngOnInit(): void {
    if (this.data?.districtGid) {
      if (!this.regionsService.regions || !this.regionsService.regions.length) {
        this.regionsService.getRegions(this.setDistrictRegionName);
      } else {
        this.setDistrictRegionName(this.regionsService.regions);
      }
    }
  }

  ngOnChanges() {
    if (this.data?.districtGid) {
      if (!this.regionsService.regions || !this.regionsService.regions.length) {
        this.regionsService.getRegions(this.setDistrictRegionName);
      } else {
        this.setDistrictRegionName(this.regionsService.regions);
      }
    }
  }

  setDistrictRegionName = (regions: Region[]) => {
    // tslint:disable-next-line: triple-equals
    const regionData = regions.find(region => region.regionGid == this.data.regionGid);
    this.data['districtRegionNameRu'] = regionData.regionNameRu;
    this.data['districtRegionNameKk'] = regionData.regionNameKk;
  };

  goKz(root: boolean = true) {
    if (root) {
      const url = this.router.url;
      const kzUrl = url.substring(0, url.indexOf('/', 1));
      this.ngZone.run(() =>
        this.router.navigate([kzUrl], { queryParams: { selectedInPreviousRoute: true } }).then(),
      );
      this.navigated.emit();

      return;
    }
    const routeUrls = this.router.url.split('/');
    routeUrls.pop();
    this.ngZone.run(() =>
      this.router
        .navigate([routeUrls.join('/')], { queryParams: { selectedInPreviousRoute: true } })
        .then(),
    );

    // setTimeout(() => {
    this.navigated.emit();
    // });
  }
}

@Component({
  selector: 'app-map-info-finance',
  templateUrl: './map-info.component-finance.html',
  styleUrls: ['./map-info.component.scss'],
})
export class MapInfoFinanceComponent extends MapInfoComponent {
  currentMonth: string = new Date().toLocaleString('ru-ru', { month: 'long', year: 'numeric' });
}

@Component({
  selector: 'app-map-info-needs',
  templateUrl: './map-info.component-needs.html',
  styleUrls: ['./map-info.component.scss'],
})
export class MapInfoNeedsComponent extends MapInfoComponent {
  currentMonth: string = new Date().toLocaleString('ru-ru', { month: 'long', year: 'numeric' });
}
