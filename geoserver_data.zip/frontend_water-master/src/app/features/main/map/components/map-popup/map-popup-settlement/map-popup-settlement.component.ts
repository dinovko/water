import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { MapPopupComponent } from '../map-popup.component';

@Component({
  selector: 'app-map-popup-settlement',
  templateUrl: './map-popup-settlement.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapPopupSettlementComponent extends MapPopupComponent {
  @Input() dataType: 'provision' | 'finance' | 'needs' = 'provision';
}
