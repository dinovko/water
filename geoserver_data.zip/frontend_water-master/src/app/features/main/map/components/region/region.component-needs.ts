import { Component } from '@angular/core';
import { RegionComponent } from './region.component';

@Component({
  selector: 'app-region-needs',
  template: `
    <div class="map-info" *ngIf="regionData && !mainService.mobileQuery?.matches">
      <app-map-info-needs [data]="regionData"></app-map-info-needs>
    </div>
    <app-map-popup-needs
      *ngIf="mapService.selectedFeature && !mainService.mobileQuery?.matches"
      [coordinates]="mapService.selectedFeature?.get('popupCoordinates')"
      [data]="mapService.selectedFeature?.get('data')"
      (opened)="onOpen($event)"
    ></app-map-popup-needs>
    <mat-tab-group *ngIf="!mainService.mobileQuery?.matches">
      <mat-tab label="Диаграмма">
        <app-diagram
          *ngIf="selectedRegionDistricts?.length"
          [inputData]="selectedRegionDistricts"
          [displayName]="'districtName' + ('Ru' | translate)"
          [diagramType]="'needs'"
        ></app-diagram>
      </mat-tab>
      <mat-tab label="Таблица">
        <app-table
          *ngIf="selectedRegionDistricts?.length"
          [inputData]="selectedRegionDistricts"
          [tableType]="'needs'"
        ></app-table>
      </mat-tab>
    </mat-tab-group>
    <app-m-bread-crumbs
      *ngIf="selectedRegionDistricts?.length && mainService.mobileQuery?.matches && regionData"
      [data]="selectedRegionDistricts"
      [mapInfo]="regionData"
    ></app-m-bread-crumbs>
  `,
})
export class RegionNeedsComponent extends RegionComponent {}
