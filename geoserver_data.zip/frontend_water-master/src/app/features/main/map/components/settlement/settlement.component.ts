import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DatasService } from 'src/app/features/datas/datas.service';
import { MatTableDataSource } from '@angular/material/table';
import { CurrentUser } from 'src/app/auth/services/current.service';
import { MainService } from 'src/app/features/main/main.service';
import { NotificationDialogComponent } from 'src/app/shared/components/notification-dialog/notification-dialog.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-settlement',
  template: '',
})
export class SettlementComponent implements OnInit {
  constructor(
    private matDialog: MatDialog,
    private datasService: DatasService,
    private activatedRoute: ActivatedRoute,
  ) {}
  settlementid: number = this.activatedRoute.snapshot.params.settlementid;
  ngOnInit(): void {
    this.datasService
      .getSettlementsData(this.settlementid)
      .toPromise()
      .then(settlementsData => {
        this.openMatDialog(settlementsData);
      })
      .catch(err => {
        // alert('Ошибка');
        let result = 'Ошибка';
        let status = 'Возникла ошибка при получении данных о СНП';
        this.result('modal', result, 'error', status);
      });
  }

  openMatDialog(data) {
    this.matDialog.open(SettlementDialog, {
      maxHeight: '90vh',
      minHeight: '50vh',
      minWidth: '50vw',
      maxWidth: '85vw',
      data,
      autoFocus: false,
    });
  }

  result(modal: any, result, res, status) {
    this.matDialog.open(NotificationDialogComponent, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
      data: { result, res, status },
    });
  }
}

@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'settlement-dialog.html',
  styleUrls: ['settlement-dialog.scss'],
})
export class SettlementDialog implements OnDestroy {
  dataSource = new MatTableDataSource();
  role = false;
  displayedColumns: string[] = [
    'projectName',
    'implementationFrom',
    'financeTotalCost',
    'financeLb',
    'financeRbKvr',
    'financeRbKds',
    'dicFinanceType',
    'finishDate',
  ];
  subscription: Subscription = new Subscription();

  constructor(
    private dialogRef: MatDialogRef<SettlementDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private _user: CurrentUser,
    public mainService: MainService,
  ) {
    const roleSubscr = _user.user$.subscribe(data => {
      if (data) {
        this.role = true;
      } else {
        this.role = false;
      }
    });
    this.subscription.add(roleSubscr);

    if (data.settlementWater) {
      if (data.settlementWater.needRbKvr == null) data.settlementWater.needRbKvr = 0;
      if (data.settlementWater.needRbKds == null) data.settlementWater.needRbKds = 0;
      if (data.settlementWater.needLb == null) data.settlementWater.needLb = 0;
      data.settlementWater.needTotalCost =
        data.settlementWater.needRbKvr +
        data.settlementWater.needRbKds +
        data.settlementWater.needLb;
      if (data.settlementWater.financeSettlementWaters) {
        data.settlementWater.financeSettlementWaters.forEach(element => {
          if (element.financeRbKds == null) element.financeRbKds = 0;
          if (element.financeRbKvr == null) element.financeRbKvr = 0;
          if (element.financeLb == null) element.financeLb = 0;
          element.financeTotalCost =
            element.financeRbKds + element.financeRbKvr + element.financeLb;
        });
        this.dataSource = new MatTableDataSource(data.settlementWater.financeSettlementWaters);
      }
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    const routeUrls = this.router.url.split('/');
    routeUrls.pop();
    if (routeUrls.length === 4) {
      this.router.navigate([routeUrls.join('/')]);
    }
  }
}
