import { Component, OnInit, Input, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import * as XLSX from 'xlsx';
import { MapService } from 'src/app/features/main/map/map.service';
import { Subscription } from 'rxjs';
import { Region } from 'src/app/shared/models/mapInfo';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit, OnDestroy {
  dataSource = new MatTableDataSource();
  displayedColumns: string[] = [
    'region',
    'accessSettlementCount',
    'notAccessSettlementCount',
    'notAccessSettlementCountLess',
    'notAccessSettlementCountMore',
  ];
  displayedColumns2: string[] = [
    'settlementNameRu',
    'population',
    'accessPopulation',
    'serviceCompany',
    'totalLengthWaterPipes',
  ];
  displayedColumnsDiagramm: string[] = ['regionFinance', 'financeRb', 'financeLb'];
  setrlementYes = false;
  regionNameRu = false;
  districtNameRu = false;
  settlementNameRu = false;
  @ViewChild('TABLE') table: ElementRef;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @Input() readonly inputData: Region[]; // = this.mapService.regions;
  @Input() readonly tableType: string;

  printTable$: Subscription;
  constructor(private mapService: MapService) {
    this.printTable$ = mapService.printTable.subscribe(print => {
      if (print) {
        this.ExportTOExcel();
      }
    });
  }

  ngOnInit(): void {
    if (this.inputData[0].settlementNameRu != null) {
      this.setrlementYes = true;
      this.displayedColumns = this.displayedColumns2;
    }
    if (this.inputData[0].regionNameRu != null) {
      this.regionNameRu = true;
    }
    if (this.inputData[0].districtNameRu != null) {
      this.districtNameRu = true;
    }
    if (this.inputData[0].settlementNameRu != null) {
      this.settlementNameRu = true;
    }
    if (this.tableType != 'potrebnost') {
      this.displayedColumns = this.displayedColumnsDiagramm;
      this.inputData.forEach(elem => {
        if (elem.financeRbKvr == null) {
          elem.financeRbKvr = 0;
        }
        if (elem.financeRbKds == null) {
          elem.financeRbKds = 0;
        }

        if (elem.needRbKvr == null) {
          elem.needRbKvr = 0;
        }
        if (elem.needRbKds == null) {
          elem.needRbKds = 0;
        }

        elem.financeRb = elem.financeRbKds + elem.financeRbKvr;
        elem.needRb = elem.needRbKvr + elem.needRbKds;
        if (elem.financeRb == 0) {
          elem.financeRb = null;
        }
        if (elem.financeLb == 0) {
          elem.financeLb = null;
        }

        if (elem.needLb == 0) {
          elem.needLb = null;
        }
        if (elem.needRb == 0) {
          elem.needRb = null;
        }
      });
    }
    this.dataSource = new MatTableDataSource(this.inputData);
    this.dataSource.sort = this.sort;
  }
  ngOnDestroy(): void {
    this.printTable$.unsubscribe();
  }
  ExportTOExcel() {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.table.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    /* save to file */
    XLSX.writeFile(wb, 'excel_water.xlsx');
  }
}
