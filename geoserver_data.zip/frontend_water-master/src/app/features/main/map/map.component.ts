import { Component, AfterViewInit } from '@angular/core';
import { MapService } from './map.service';
import { MatButton } from '@angular/material/button';
import { constants } from 'src/app/сonstants';
import { MainService } from '../main.service';
import { MatDialog } from '@angular/material/dialog';
import { TechSupportComponent } from 'src/app/shared/components/tech-support/tech-support.component';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss'],
})
export class MapComponent implements AfterViewInit {
  constructor(
    private mapService: MapService,
    public mainService: MainService,
    private matDialog: MatDialog,
  ) {}

  ngAfterViewInit() {
    this.mapService.initMap();
  }

  zoom(zoom) {
    const view = this.mapService.map.getView();
    zoom += view.getZoom();
    view.animate({
      zoom,
      duration: constants.map.duration,
    });
  }

  toTechSupport() {
    this.matDialog.open(TechSupportComponent, {
      maxHeight: '90vh',
      minHeight: '40vh',
      minWidth: '30vw',
      maxWidth: '90vw',
      panelClass: 'dialog_withoutPadding_with_radius',
    });
  }

  onClickPrint = (printBnt: MatButton) => {
    let mapInfo: any = document.getElementsByClassName('map-info');
    let diagramInfo: any = document.getElementById('mainDiagram');
    this.mapService.print(printBnt, mapInfo.length > 0 ? mapInfo[0] : null, diagramInfo);
  };
}
