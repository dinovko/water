import { Component } from '@angular/core';

@Component({
  selector: 'app-needs',
  templateUrl: './needs.component.html',
})
export class NeedsComponent {
  constructor() {}
}
