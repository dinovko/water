import { Component } from '@angular/core';

@Component({
  selector: 'app-provision',
  templateUrl: './provision.component.html',
})
export class ProvisionComponent {
  constructor() {}
}
