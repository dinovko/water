import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RegionsService } from '../../services/regions.service';
import { MatDialog } from '@angular/material/dialog';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { Message } from '../../models/mapInfo';

@Component({
  selector: 'app-tech-support',
  templateUrl: './tech-support.component.html',
  styleUrls: ['./tech-support.component.scss'],
})
export class TechSupportComponent implements OnInit {
  form: FormGroup;
  public phoneMask = [
    '+',
    /7/,
    '(',
    /[1-9]/,
    /\d/,
    /\d/,
    ')',
    ' ',
    /\d/,
    /\d/,
    /\d/,
    '-',
    /\d/,
    /\d/,
    '-',
    /\d/,
    /\d/,
  ];

  constructor(private regionService: RegionsService, private matDialog: MatDialog) {}

  ngOnInit(): void {
    this.form = new FormGroup({
      email: new FormControl(null, [Validators.email, Validators.required]),
      name: new FormControl(null, Validators.required),
      phone: new FormControl(null, Validators.required),
      text: new FormControl(null, Validators.required),
    });
  }

  submit() {
    if (this.form.invalid) {
      return;
    }

    const message: Message = {
      fullName: this.form.value.name,
      email: this.form.value.email,
      text: this.form.value.text,
      phoneNumber: this.form.value.phone.toString(),
    };

    console.log('message: ', message);
    this.regionService
      .sendSimpleMessageToEmail(message)
      .toPromise()
      .then((data: any) => {
        let result = 'Ваше сообщение успешно отправлено';
        let status = 'Обращение в техподдержку';
        this.result('modal', result, 'success', status);
      })
      .catch(err => {
        let result = 'Ошибка';
        let status = 'Обращение в техподдержку';
        this.result('modal', result, 'error', status);
      });
  }

  result(modal: any, result, res, status) {
    this.matDialog.open(NotificationDialogComponent, {
      maxHeight: '100vh',
      minHeight: '25vh',
      minWidth: '25vw',
      maxWidth: '100vw',
      data: { result, res, status },
    });
  }
}
