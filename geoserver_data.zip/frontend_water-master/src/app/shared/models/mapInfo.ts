export interface FullInfoKz {
  population: number; //  - Население СНП
  settlementCount: number; //  - количество СНП
  accessPopulation: number; //  - население (имеет доступ)
  accessSettlementCount: number; //  - количество СНП (имеет доступ)
  notAccessPopulation: number; //  - население (не имеет доступ)
  notAccessSettlementCount: number; //  - количество СНП (не имеет доступ)
  notAccessPopulationMore: number; //  - население больше 200 (не имеет доступ)
  notAccessSettlementCountMore: number; //  - количество СНП (больше 200)
  notAccessPopulationLess: number; //  - население меньше 200 (не имеет доступ)
  notAccessSettlementCountLess: number; //  - количество СНП (менее 200)
  totalLengthWaterPipes: number; //  - протяженность водопроводов
  outworn: number; //  - изношенных водопроводов процент
}

export interface Message {
  fullName: string;
  email: string;
  text: string;
  phoneNumber: string;
}

export interface Region {
  population: number; // population - население
  settlementCount: number; // settlementCount - количество СНП
  accessPopulation: number; // accessPopulation - имеет доступ к ЦВ (население)
  accessSettlementCount: number; // accessSettlementCount - имеет доступ к ЦВ (количество СНП)
  notAccessPopulation: number; // notAccessPopulation - НЕ имеет доступ к ЦВ (население)
  notAccessSettlementCount: number; // notAccessSettlementCount - НЕ имеет доступ к ЦВ (количество СНП)
  notAccessPopulationMore: number; // notAccessPopulationMore - НЕ имеет доступ к ЦВ (население где БОЛЬШЕ 200 человек)
  notAccessSettlementCountMore: number;
  // notAccessSettlementCountMore - НЕ имеет доступ к ЦВ (количество СНП где население БОЛЬШЕ 200 человек)
  notAccessPopulationLess: number; // notAccessPopulationLess - НЕ имеет доступ к ЦВ (население где МЕНЬШЕ 200 человек)
  notAccessSettlementCountLess: number;
  // notAccessSettlementCountLess - - НЕ имеет доступ к ЦВ (количество СНП где население МЕНЬШЕ 200 человек)
  totalLengthWaterPipes: number; // totalLengthWaterPipes - протяженность сетей
  deterioration: any; // type? // deterioration - Износ сетей
  needTotalCost: number;
  needLb: number;
  needRbKvr: number; // type? // needRbKvr - Потребность из РБ КВР
  needRbKds: number; // type? // needRbKds - Потребность из РБ КДС
  regionGid: number; // regionGid - идентификатор области
  regionNameRu: string; // regionNameRu - название области на рус
  regionNameKk: string; // regionNameKk - название области на каз
  districtGid: number; // districtGid - идентификатор района
  districtNameRu: string; // districtNameRu - название района на рус
  districtNameKk: string; // districtNameKk  - название района на каз
  settlementGid: number; // settlementGid  - идентификатор СНП
  settlementNameRu: string; // settlementNameRu  - название СНП на рус
  settlementNameKk: string; // settlementNameKk - название СНП на каз
  financeTotalCost: number; // financeTotalCost - финансирование ОБЩАЯ
  financeRbKvr: number; // type? // financeRbKvr - финансирование РБ КВР
  financeRbKds: number; // type? // financeRbKds - финансирование РБ КДС
  financeLb: number; // type? // financeLb - Финансирование МБ
  wkt: string; // wkt - геометрия
  isSpecProject: number;
  serviceCompany: string;
  financeRb: number;
  needRb: number;
  isGroupFinance: any;
}
