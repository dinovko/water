import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'spaces',
})
export class SpacesPipe implements PipeTransform {
  transform(value: string): string {
    if (!value) {
      return '';
    }
    return value.replace(/\u00a0/g, ' ');
  }
}
