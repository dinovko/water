import { Injectable } from '@angular/core';
import { Region, Message } from '../models/mapInfo';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiConfig } from 'src/api.config';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class RegionsService {
  fullInfoKz: Region;
  regions: Region[];
  districts: Region[] = [];
  cities: Region[] = [];
  citiesTable: Region[] = [];
  dataTable = new BehaviorSubject([]);

  constructor(private http: HttpClient) {}

  getFullInfoKz() {
    this.http
      .get(ApiConfig.waterApi + '/public/water-supply/fullInfoKz')
      .toPromise()
      .then((data: Region) => {
        this.fullInfoKz = data;
      });
  }

  getRegions(callback: (regions: Region[]) => void = ([]) => {}) {
    return this.http
      .get(ApiConfig.waterApi + '/public/water-supply/allRegionsCommon')
      .toPromise()
      .then((regions: Region[]) => {
        this.regions = regions;
        this.dataTable.next(regions);
        return this.regions;
      })
      .then(callback);
  }

  getDistricts(regionId: number, callback: (regions: Region[]) => void = ([]) => {}) {
    return this.http
      .get(`${ApiConfig.waterApi}/public/water-supply/districtsByRegionId/${regionId}`)
      .toPromise()
      .then((districts: Region[]) => {
        this.dataTable.next(districts);
        const selectedDistricts = districts.map(district => {
          district.regionGid = regionId;
          return district;
        });
        this.districts = [...this.districts, ...selectedDistricts];

        return selectedDistricts;
      })
      .then(callback);
  }

  getCities(districtId: number, callback: (regions: Region[]) => void = ([]) => {}) {
    return this.http
      .get(`${ApiConfig.waterApi}/public/water-supply/settlementsByDistrictId/${districtId}`)
      .toPromise()
      .then((cities: Region[]) => {
        this.dataTable.next(cities);
        const selectedCities = cities.map(district => {
          district.districtGid = districtId;
          return district;
        });
        this.cities = [...this.cities, ...selectedCities];

        return selectedCities;
      })
      .then(callback);
  }

  getCitiesTable(districtId: number, callback: (regions: Region[]) => void = ([]) => {}) {
    return this.http
      .get(`${ApiConfig.waterApi}/public/water-supply/settlementsTableByDistrictId/${districtId}`)
      .toPromise()
      .then((citiesTable: Region[]) => {
        this.dataTable.next(citiesTable);
        const selectedCitiesTable = citiesTable.map(district => {
          district.districtGid = districtId;
          return district;
        });
        this.citiesTable = [...this.citiesTable, ...selectedCitiesTable];

        return selectedCitiesTable;
      })
      .then(callback);
  }

  sendSimpleMessageToEmail(message: Message): Observable<any> {
    return this.http.post(
      `${ApiConfig.waterApi}/public/common/sendSimpleMessageToEmail?text=${message.text}&email=${message.email}&phoneNumber=${message.phoneNumber}&fullName=${message.fullName}`,
      {},
      { responseType: 'text' },
    );
  }
}
