import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialModule } from '../material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { LanguagesComponent } from './components/languages/languages.component';
import { RouterModule } from '@angular/router';
import { ChartsModule } from 'ng2-charts';
import { RolePipe } from '../auth/services/role-pipe';
import { ForbiddenComponent } from './components/forbidden/forbidden.component';
import { NotificationDialogComponent } from './components/notification-dialog/notification-dialog.component';
import { SpacesPipe } from './pipes/spaces.pipe';
import { SortArrayPipe } from './pipes/sort-array.pipe';
import { NullableDataPipe } from './pipes/nullable-data.pipe';
import { TechSupportComponent } from './components/tech-support/tech-support.component';
import { TextMaskModule } from 'angular2-text-mask';

@NgModule({
  declarations: [
    LanguagesComponent,
    RolePipe,
    ForbiddenComponent,
    NotificationDialogComponent,
    SpacesPipe,
    SortArrayPipe,
    NullableDataPipe,
    TechSupportComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    TranslateModule,
    MaterialModule,
    FlexLayoutModule,
    RouterModule,
    ReactiveFormsModule,
    TextMaskModule,
  ],
  exports: [
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    LanguagesComponent,
    TranslateModule,
    RolePipe,
    SpacesPipe,
    SortArrayPipe,
    NullableDataPipe,
    ChartsModule,
  ],
  entryComponents: [NotificationDialogComponent],
})
export class SharedModule {}
