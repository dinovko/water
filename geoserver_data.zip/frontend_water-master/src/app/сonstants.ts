export namespace constants {
  export const noGreetingTime: string = '259200'; // время, в течении которого не показывать окно приветствия, в секундах

  export const mainTabs = [
    { label: 'Обеспеченность', route: 'provision', iconClass: 'fas fa-check-circle', role: true },
    {
      label: 'Финансирование',
      route: 'finance',
      iconClass: 'far fa-credit-card',
      role: false,
    },
    { label: 'Потребность', route: 'needs', iconClass: 'far fa-calendar-check', role: true },
  ];

  export namespace geoserver {
    export const workSpace = 'mapwater';
  }

  export namespace map {
    export const zoom: number = 3;
    export const maxZoom: number = 6;
    export const regionMaxZoom: number = 15;
    // export const extent: [number, number, number, number] = [
    //   979816.96,
    //   2676191.74,
    //   11211387.71,
    //   9786716.99,
    // ];
    export const extent: [number, number, number, number] = [
      4579816.96,
      4676191.74,
      10211387.71,
      7786716.99,
    ];
    export const duration = 500;
    export const zoomPadding: [number, number, number, number] = [50, 50, 50, 50];
    export const center: [number, number] = [3393957.48, 6272481.15];
  }

  export namespace printMap {
    export const defaultFormat = 'a4';
    export const dims = {
      a0: [1189, 841],
      a1: [841, 594],
      a2: [594, 420],
      a3: [420, 297],
      a4: [297, 210],
      a5: [210, 148],
    };
    export const defaultResolution = 150; // 72, 150, 300
  }
}
